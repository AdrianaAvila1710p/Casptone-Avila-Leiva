-- Requerido por el registro de clientas con ON CONFLICT.
-- Si existen correos duplicados, PostgreSQL detiene la migración sin borrar datos.
BEGIN;
CREATE UNIQUE INDEX IF NOT EXISTS clienta_correo_unico
ON clienta (LOWER(TRIM(correo)));
COMMIT;
