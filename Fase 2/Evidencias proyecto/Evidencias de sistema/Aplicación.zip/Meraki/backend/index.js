// Importamos Express.
const express = require("express");
const {normalizarNegocio,crearCuenta,montarIncorporacion}=require('./incorporacion');
const {montarFotos}=require('./fotos-servicios');
const {abonoCLPValido}=require('./montos-abono');

// Importamos el SDK de Transbank para gestionar abonos mediante Webpay Plus.
const {
    WebpayPlus,
    Options,
    IntegrationCommerceCodes,
    IntegrationApiKeys,
    Environment
} = require("transbank-sdk");

const {montarProcesamientoWebpay, PLAZO_WEBPAY_MS} = require('./procesamiento-webpay');
const {crearReferenciasWebpay, montarLecturaResultado, urlRetornoVisual} = require('./resultado-webpay');

// Configuración de Webpay Plus para pruebas.
// No se utilizan credenciales de producción.
const webpay = new WebpayPlus.Transaction(
    new Options(
        IntegrationCommerceCodes.WEBPAY_PLUS,
        IntegrationApiKeys.WEBPAY,
        Environment.Integration,
        PLAZO_WEBPAY_MS
    )
);

// Importamos bcrypt para proteger las contraseñas.
const bcrypt = require("bcrypt");

// Importamos las herramientas para administrar sesiones.
const session = require("express-session");

// Permitimos almacenar las sesiones en PostgreSQL.
const connectPgSimple = require("connect-pg-simple");
const PgSession = connectPgSimple(session);

// Creamos la aplicación que utilizará Express.
const app = express();

// Diagnóstico del sistema original: bloquear antes de crear operaciones locales.
app.use((req,res,next)=>{
    if(process.env.MERAKI_PROVEEDORES_EXTERNOS==='0' &&
       (/^\/api\/abonos(?:\/|$)/.test(req.path) ||
        (/^\/api\/suscripcion(?:\/|$)/.test(req.path) && (req.path==='/api/suscripcion/retorno'||!['GET','HEAD'].includes(req.method))))) {
        return res.status(503).json({codigo:'PROVEEDORES_DESACTIVADOS',mensaje:'Operaciones externas desactivadas durante la revisión local.'});
    }
    next();
});

// Permitimos que el Backend reciba datos en formato JSON.
// Esto será necesario para registrar reservas desde el Front Office.
app.use(express.json());

// Permitir recibir formularios enviados por Webpay Plus.
app.use(express.urlencoded({ extended: false }));

// Ruta principal para comprobar el funcionamiento del Backend.
app.get("/", (req, res) => {
    res.send("Bienvenida al Backend de Meraki");
});

// Importamos la conexión con PostgreSQL.
const pool = require("./db");
const {crearNotificaciones,montarRutas}=require('./notificaciones');
const {registrar:registrarNotificacionConfirmacion,notificar:notificarReservaConfirmada}=crearNotificaciones(pool);
// Comprobamos que exista la clave privada de sesiones.
if (!process.env.SESSION_SECRET) {
    throw new Error("Falta SESSION_SECRET en el archivo .env");
}
const referenciasWebpay = crearReferenciasWebpay(process.env.SESSION_SECRET);
montarLecturaResultado(app,pool,referenciasWebpay);

// Mensaje temporal para verificar que el servidor
// está cargando la configuración actual de sesiones.
console.log("MERAKI: configuración de sesiones cargada");

// Configuramos las sesiones de las emprendedoras.
app.use(session({
    // Nombre de la cookie de Meraki.
    name: "meraki.sid",

    // Clave privada utilizada para firmar la cookie.
    secret: process.env.SESSION_SECRET,

    // Almacenamos las sesiones en PostgreSQL.
    store: new PgSession({
        pool: pool,
        tableName: "sesion_meraki",
        createTableIfMissing: true
    }),

    // Evitamos guardar sesiones si no han cambiado.
    resave: false,

    // No creamos sesiones para visitantes que no han iniciado sesión.
    saveUninitialized: false,

    cookie: {
        // JavaScript del navegador no puede leer esta cookie.
        httpOnly: true,

        // Reduce el envío de cookies en solicitudes entre sitios.
        sameSite: "lax",

        // En desarrollo local utilizamos HTTP.
        // En producción con HTTPS deberá cambiarse a true.
        secure: false,

        // La sesión dura dos horas desde que se emite la cookie.
        maxAge: 2 * 60 * 60 * 1000
    }
}));
// Verificamos que la emprendedora haya iniciado sesión.
// Esta función protegerá las rutas privadas del Back Office.
function verificarSesion(req, res, next) {

    // Si no existe una emprendedora autenticada, rechazamos el acceso.
    if (!req.session || !req.session.idEmprendedora) {
        return res.status(401).json({
            mensaje: "Debes iniciar sesión para acceder al Back Office"
        });
    }

    // Si existe una sesión, permitimos continuar.
    next();
}

// Ruta para comprobar que el Backend puede consultar PostgreSQL.
montarRutas(app,pool,verificarSesion,notificarReservaConfirmada);
const {crearSuscripciones,montarRutasSuscripcion,iniciarPlanificador}=require('./suscripciones');
const suscripciones=crearSuscripciones({pool});
montarRutasSuscripcion(app,suscripciones,verificarSesion);
require('./acceso-suscripcion').montarRestricciones(app,pool,verificarSesion);
const gestionesReserva=require('./gestiones-reserva');
gestionesReserva.montar(app,pool,verificarSesion);
require('./reservas-invitadas').montar(app,pool,process.env.SESSION_SECRET);
const path=require('path');
app.use('/front-office',express.static(path.join(__dirname,'../frontend/front-office')));
app.use('/back-office',express.static(path.join(__dirname,'../frontend/back-office')));
app.use('/consulta',(req,res,next)=>{res.set('Referrer-Policy','no-referrer');res.set('Cache-Control','no-store');next();},express.static(path.join(__dirname,'../frontend/consulta')));
app.use('/api/reservas/consulta',(req,res,next)=>{res.set('Cache-Control','no-store');res.set('Referrer-Policy','no-referrer');next();});
app.get("/api/estado-db", async (req, res) => {
    try {
        // Consultamos el nombre de la base de datos conectada.
        const resultado = await pool.query(
            "SELECT current_database() AS nombre"
        );

        // Enviamos una respuesta en formato JSON.
        res.json({
            mensaje: "Conexión exitosa con PostgreSQL",
            base_datos: resultado.rows[0].nombre
        });

    } catch (error) {
        // Registramos el error en la terminal.
        console.error("Error al consultar PostgreSQL:", error.message);

        // Informamos que ocurrió un error en el servidor.
        res.status(500).json({
            mensaje: "Error al conectar con la base de datos"
        });
    }
});
// Ruta para consultar las categorías de servicios de Meraki.
app.get("/api/categorias", async (req, res) => {
    try {
        // Obtenemos las categorías guardadas en PostgreSQL.
        const resultado = await pool.query(
            "SELECT id_categoria, nombre, descripcion FROM categoria ORDER BY id_categoria"
        );

        // Enviamos las categorías al navegador en formato JSON.
        res.json(resultado.rows);

    } catch (error) {
        // Mostramos el error en la terminal.
        console.error("Error al consultar categorías:", error.message);

        // Informamos que la consulta no se pudo completar.
        res.status(500).json({
            mensaje: "Error al obtener las categorías"
        });
    }
});



// Ruta para consultar los servicios activos de Meraki.
app.get("/api/servicios", async (req, res) => {
    try {
        // Consultamos los servicios y los nombres de sus emprendimientos y categorías.
        const resultado = await pool.query(`
            SELECT
                s.id_servicio,
                s.nombre AS servicio,
                s.descripcion,
                e.nombre AS emprendimiento,
                c.nombre AS categoria,
                s.precio,
                s.duracion_min,
                s.monto_abono,
                (SELECT i.url FROM imagen_servicio i WHERE i.id_servicio=s.id_servicio AND i.url LIKE '/media/servicios/%' ORDER BY i.id_imagen DESC LIMIT 1) AS imagen_url
            FROM servicio s
            INNER JOIN emprendimiento e
                ON s.id_emprendimiento = e.id_emprendimiento
            INNER JOIN categoria c
                ON s.id_categoria = c.id_categoria
            WHERE s.activo = TRUE
              AND e.estado = TRUE
            ORDER BY s.nombre;
        `);

        // Enviamos los servicios al navegador en formato JSON.
        res.json(resultado.rows);

    } catch (error) {
        // Mostramos el error en la terminal.
        console.error("Error al consultar servicios:", error.message);

        // Respondemos con un error si la consulta falla.
        res.status(500).json({
            mensaje: "Error al obtener los servicios"
        });
    }
});
// Ruta para consultar los servicios propios del Back Office.
// Incluye servicios activos y desactivados.
app.get("/api/mis-servicios", verificarSesion, async (req, res) => {
    try {

        // Consultamos únicamente los servicios de los
        // emprendimientos de la emprendedora autenticada.
        const resultado = await pool.query(`
            SELECT
                s.id_servicio,
                s.id_emprendimiento,
                e.nombre AS emprendimiento,
                s.id_categoria,
                c.nombre AS categoria,
                s.nombre AS servicio,
                s.descripcion,
                s.precio,
                s.duracion_min,
                s.monto_abono,
                (SELECT i.url FROM imagen_servicio i WHERE i.id_servicio=s.id_servicio AND i.url LIKE '/media/servicios/%' ORDER BY i.id_imagen DESC LIMIT 1) AS imagen_url,
                s.activo,
                EXISTS (SELECT 1 FROM trabajadora_servicio ts JOIN trabajadora t USING(id_trabajadora)
                  WHERE ts.id_servicio=s.id_servicio AND t.activa=TRUE AND t.id_emprendimiento=s.id_emprendimiento) AS tiene_profesional_activa
            FROM servicio s
            INNER JOIN emprendimiento e
                ON s.id_emprendimiento = e.id_emprendimiento
            INNER JOIN categoria c
                ON s.id_categoria = c.id_categoria
            WHERE e.id_emprendedora = $1
            ORDER BY s.id_servicio;
        `, [req.session.idEmprendedora]);

        // Enviamos los servicios al Back Office.
        return res.json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar servicios propios:", error.message);

        return res.status(500).json({
            mensaje: "No se pudieron obtener los servicios"
        });
    }
});
// Ruta para consultar las trabajadoras del Back Office.
// Solo muestra las trabajadoras de los emprendimientos propios.
app.get("/api/mis-trabajadoras", verificarSesion, async (req, res) => {
    try {

        // Consultamos las trabajadoras de la emprendedora autenticada.
        const resultado = await pool.query(`
            SELECT
                t.id_trabajadora,
                t.id_emprendimiento,
                e.nombre AS emprendimiento,
                t.nombre,
                t.apellido,
                t.descripcion,
                t.activa
            FROM trabajadora t
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            WHERE e.id_emprendedora = $1
            ORDER BY t.id_trabajadora;
        `, [req.session.idEmprendedora]);

        // Enviamos las trabajadoras al Back Office.
        return res.json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar trabajadoras:", error.message);

        return res.status(500).json({
            mensaje: "No se pudieron obtener las trabajadoras"
        });
    }
});


// Ruta para consultar los servicios asignados a una trabajadora.
// Solo permite acceder a trabajadoras de los emprendimientos propios.

// ============================================================
// CONSULTAR SERVICIOS ASIGNADOS A UNA TRABAJADORA
// ============================================================

app.get("/api/trabajadoras/:id/servicios", verificarSesion, async (req, res) => {
    try {
        const idTrabajadora = Number(req.params.id);

        // Validamos el identificador de la trabajadora.
        if (!Number.isSafeInteger(idTrabajadora) || idTrabajadora <= 0) {
            return res.status(400).json({
                mensaje: "Debes indicar una trabajadora válida"
            });
        }

        // Verificamos que la trabajadora pertenezca
        // a la emprendedora que inició sesión.
        const propiedad = await pool.query(`
            SELECT
                t.id_trabajadora,
                t.nombre,
                t.id_emprendimiento
            FROM trabajadora t
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            WHERE t.id_trabajadora = $1
              AND e.id_emprendedora = $2;
        `, [
            idTrabajadora,
            req.session.idEmprendedora
        ]);

        if (propiedad.rows.length === 0) {
            return res.status(404).json({
                mensaje: "La trabajadora no existe"
            });
        }

        // Consultamos los servicios asignados a la trabajadora.
        // Incluimos servicios activos e inactivos para el Back Office.
        const resultado = await pool.query(`
            SELECT
                s.id_servicio,
                s.id_emprendimiento,
                s.nombre,
                s.descripcion,
                s.duracion_min,
                s.precio,
                s.activo
            FROM trabajadora_servicio ts
            INNER JOIN servicio s
                ON ts.id_servicio = s.id_servicio
            WHERE ts.id_trabajadora = $1
              AND s.id_emprendimiento = $2
            ORDER BY s.nombre;
        `, [
            idTrabajadora,
            propiedad.rows[0].id_emprendimiento
        ]);

        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar servicios asignados:", error.message);

        return res.status(500).json({
            mensaje: "No se pudieron consultar los servicios de la trabajadora"
        });
    }
});


// ============================================================
// ASIGNAR UN SERVICIO A UNA TRABAJADORA
// ============================================================

app.post("/api/trabajadoras/:id/servicios", verificarSesion, async (req, res) => {
    try {
        if (Object.keys(req.body || {}).some(campo => campo !== 'id_servicio')) {
            return res.status(400).json({mensaje:'La asignación solo admite el identificador del servicio'});
        }
        const idTrabajadora = Number(req.params.id);
        const { id_servicio } = req.body || {};
        const idServicio = Number(id_servicio);

        // Validamos los identificadores.
        if (
            !Number.isSafeInteger(idTrabajadora) ||
            idTrabajadora <= 0 ||
            !Number.isSafeInteger(idServicio) ||
            idServicio <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar una trabajadora y un servicio válidos"
            });
        }

        // Comprobamos que ambos pertenezcan al mismo
        // emprendimiento y estén activos.
        const propiedad = await pool.query(`
            SELECT
                t.id_trabajadora,
                s.id_servicio,
                t.id_emprendimiento
            FROM trabajadora t
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            INNER JOIN servicio s
                ON s.id_emprendimiento = e.id_emprendimiento
            WHERE t.id_trabajadora = $1
              AND s.id_servicio = $2
              AND e.id_emprendedora = $3
              AND t.activa = TRUE
              AND s.activo = TRUE;
        `, [
            idTrabajadora,
            idServicio,
            req.session.idEmprendedora
        ]);

        if (propiedad.rows.length === 0) {
            return res.status(404).json({
                mensaje: "No se encontró una trabajadora activa y un servicio activo válidos para este emprendimiento"
            });
        }

        // Registramos la asignación, evitando duplicados.
        const resultado = await pool.query(`
            INSERT INTO trabajadora_servicio (
                id_trabajadora,
                id_servicio
            )
            VALUES ($1, $2)
            ON CONFLICT (id_trabajadora, id_servicio)
            DO NOTHING
            RETURNING id_trabajadora, id_servicio;
        `, [
            idTrabajadora,
            idServicio
        ]);

        // La asignación ya existía.
        if (resultado.rows.length === 0) {
            return res.status(409).json({
                mensaje: "Este servicio ya está asignado a la trabajadora"
            });
        }

        return res.status(201).json({
            mensaje: "Servicio asignado correctamente",
            asignacion: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al asignar servicio:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo asignar el servicio a la trabajadora"
        });
    }
});



/* ============================================================
   DESASIGNAR UN SERVICIO DE UNA TRABAJADORA
   ============================================================ */

app.delete("/api/trabajadoras/:id/servicios/:id_servicio", verificarSesion, async (req, res) => {
    try {
        // Obtenemos los identificadores enviados en la URL.
        const idTrabajadora = Number(req.params.id);
        const idServicio = Number(req.params.id_servicio);

        // Validamos que ambos identificadores sean enteros positivos.
        if (
            !Number.isSafeInteger(idTrabajadora) ||
            idTrabajadora <= 0 ||
            !Number.isSafeInteger(idServicio) ||
            idServicio <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar una trabajadora y un servicio válidos"
            });
        }

        // Comprobamos que la trabajadora y el servicio
        // pertenezcan al mismo emprendimiento de la sesión.
        const propiedad = await pool.query(`
            SELECT
                t.id_trabajadora,
                s.id_servicio
            FROM trabajadora t
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            INNER JOIN servicio s
                ON s.id_emprendimiento = e.id_emprendimiento
            WHERE t.id_trabajadora = $1
              AND s.id_servicio = $2
              AND e.id_emprendedora = $3;
        `, [
            idTrabajadora,
            idServicio,
            req.session.idEmprendedora
        ]);

        // Rechazamos registros inexistentes o ajenos.
        if (propiedad.rows.length === 0) {
            return res.status(404).json({
                mensaje: "No se encontró la trabajadora o el servicio en tu emprendimiento"
            });
        }

        // Eliminamos únicamente la relación entre ambos.
        const resultado = await pool.query(`
            DELETE FROM trabajadora_servicio
            WHERE id_trabajadora = $1
              AND id_servicio = $2
            RETURNING id_trabajadora, id_servicio;
        `, [
            idTrabajadora,
            idServicio
        ]);

        // Comprobamos que existiera una asignación.
        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El servicio no está asignado a esta trabajadora"
            });
        }

        // Confirmamos la desasignación.
        return res.status(200).json({
            mensaje: "Servicio desasignado correctamente",
            asignacion: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al desasignar servicio:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo desasignar el servicio de la trabajadora"
        });
    }
});






// Ruta para consultar los horarios de atención del Back Office.


// Incluye horarios activos e inactivos de los negocios propios.
app.get("/api/mis-horarios", verificarSesion, async (req, res) => {
    try {
        // Consultamos los horarios de las trabajadoras
        // de los emprendimientos de la sesión.
        const resultado = await pool.query(`
            SELECT
                h.id_horario,
                h.id_trabajadora,
                t.nombre AS trabajadora,
                t.id_emprendimiento,
                e.nombre AS emprendimiento,
                h.dia_semana,
                h.hora_inicio,
                h.hora_fin,
                h.activo
            FROM horario_atencion h
            INNER JOIN trabajadora t
                ON h.id_trabajadora = t.id_trabajadora
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            WHERE e.id_emprendedora = $1
            ORDER BY
                t.id_trabajadora,
                h.dia_semana,
                h.hora_inicio;
        `, [req.session.idEmprendedora]);

        return res.json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar horarios:", error.message);

        return res.status(500).json({
            mensaje: "No se pudieron obtener los horarios"
        });
    }
});

// Ruta para registrar horarios de atención del Back Office.
// Solo las emprendedoras autenticadas pueden registrar horarios.
app.post("/api/horarios", verificarSesion, async (req, res) => {
    try {
        const permitidos=['id_trabajadora','dia_semana','hora_inicio','hora_fin'];
        if(Object.keys(req.body||{}).some(campo=>!permitidos.includes(campo))){
            return res.status(400).json({mensaje:'La solicitud contiene campos de horario no permitidos'});
        }
        // Recibimos los datos del horario.
        const {
            id_trabajadora,
            dia_semana,
            hora_inicio,
            hora_fin
        } = req.body || {};

        // Convertimos el identificador de la trabajadora a número.
const idTrabajadora = Number(id_trabajadora);

// Validamos que sea un identificador entero positivo.
if (
    !Number.isSafeInteger(idTrabajadora) ||
    idTrabajadora <= 0
) {
    return res.status(400).json({
        mensaje: "Debes indicar una trabajadora válida"
    });
}

// Comprobamos que la trabajadora pertenezca a un
// emprendimiento de la emprendedora autenticada.
const propiedad = await pool.query(`
    SELECT t.id_trabajadora, t.activa
    FROM trabajadora t
    INNER JOIN emprendimiento e
        ON t.id_emprendimiento = e.id_emprendimiento
    WHERE t.id_trabajadora = $1
      AND e.id_emprendedora = $2;
`, [idTrabajadora, req.session.idEmprendedora]);

// Rechazamos trabajadoras inexistentes o ajenas.
if (propiedad.rows.length === 0) {
    return res.status(404).json({
        mensaje: "La trabajadora no existe"
    });
}

// No permitimos registrar horarios para trabajadoras desactivadas.
if (propiedad.rows[0].activa === false) {
    return res.status(409).json({
        mensaje: "No puedes registrar horarios para una trabajadora desactivada"
    });
}

// Definimos los días válidos para mantener el mismo
// formato utilizado por la API de disponibilidad.
const diasValidos = [
    "lunes",
    "martes",
    "miercoles",
    "jueves",
    "viernes",
    "sabado",
    "domingo"
];

// Validamos el día de la semana.
if (
    typeof dia_semana !== "string" ||
    !diasValidos.includes(dia_semana.trim().toLowerCase())
) {
    return res.status(400).json({
        mensaje: "Debes indicar un día de la semana válido"
    });
}

// Normalizamos el día antes de guardarlo.
const diaSemanaLimpio = dia_semana.trim().toLowerCase();

// Validamos que las horas tengan formato HH:MM o HH:MM:SS.
const formatoHora = /^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/;

if (
    typeof hora_inicio !== "string" ||
    typeof hora_fin !== "string" ||
    !formatoHora.test(hora_inicio) ||
    !formatoHora.test(hora_fin)
) {
    return res.status(400).json({
        mensaje: "Las horas deben tener formato HH:MM o HH:MM:SS"
    });
}

// Normalizamos las horas a HH:MM:SS.
const horaInicioLimpia =
    hora_inicio.length === 5 ? `${hora_inicio}:00` : hora_inicio;

const horaFinLimpia =
    hora_fin.length === 5 ? `${hora_fin}:00` : hora_fin;

// Comprobamos que el horario termine después de comenzar.
if (horaFinLimpia <= horaInicioLimpia) {
    return res.status(400).json({
        mensaje: "La hora de término debe ser posterior a la hora de inicio"
    });
}

// Comprobamos si ya existe un horario activo que se cruce
// con el nuevo horario de la misma trabajadora y día.
const superposicion = await pool.query(`
    SELECT id_horario
    FROM horario_atencion
    WHERE id_trabajadora = $1
      AND dia_semana = $2
      AND activo = TRUE
      AND hora_inicio < $4::time
      AND hora_fin > $3::time
    LIMIT 1;
`, [
    idTrabajadora,
    diaSemanaLimpio,
    horaInicioLimpia,
    horaFinLimpia
]);

// Si encontramos un horario superpuesto, rechazamos el registro.
if (superposicion.rows.length > 0) {
    return res.status(409).json({
        mensaje: "La trabajadora ya tiene un horario que se superpone con el indicado"
    });
}

// Registramos el horario de atención en PostgreSQL.
const resultado = await pool.query(`
    INSERT INTO horario_atencion (
        id_trabajadora,
        dia_semana,
        hora_inicio,
        hora_fin
    )
    VALUES ($1, $2, $3::time, $4::time)
    RETURNING
        id_horario,
        id_trabajadora,
        dia_semana,
        hora_inicio,
        hora_fin,
        activo;
`, [
    idTrabajadora,
    diaSemanaLimpio,
    horaInicioLimpia,
    horaFinLimpia
]);

// Confirmamos que el horario fue registrado.
return res.status(201).json({
    mensaje: "Horario registrado correctamente",
    horario: resultado.rows[0]
});

    } catch (error) {
    // Detectamos cuando PostgreSQL rechaza horarios superpuestos.
    if (error.code === "23P01") {
        return res.status(409).json({
            mensaje: "La trabajadora ya tiene un horario que se superpone con el indicado"
        });
    }

    console.error("Error al registrar horario:", error.message);

    return res.status(500).json({
        mensaje: "No se pudo registrar el horario"
    });
}
});



// Ruta para editar horarios de atención del Back Office.
app.patch("/api/horarios/:id", verificarSesion, async (req, res) => {
    try {
        const campos=Object.keys(req.body||{});
        if(!campos.length||campos.some(campo=>!['dia_semana','hora_inicio','hora_fin'].includes(campo))){
            return res.status(400).json({mensaje:'Indica al menos un campo editable del horario'});
        }
        // Identificamos el horario que se desea modificar.
        const idHorario = Number(req.params.id);

        // Validamos el identificador.
        if (!Number.isSafeInteger(idHorario) || idHorario <= 0) {
            return res.status(400).json({
                mensaje: "Debes indicar un horario válido"
            });
        }

       // Buscamos el horario y comprobamos que pertenezca
// a un emprendimiento de la emprendedora autenticada.
const propiedad = await pool.query(`
    SELECT
        h.id_horario,
        h.id_trabajadora,
        h.dia_semana,
        h.hora_inicio,
        h.hora_fin,
        h.activo
    FROM horario_atencion h
    INNER JOIN trabajadora t
        ON h.id_trabajadora = t.id_trabajadora
    INNER JOIN emprendimiento e
        ON t.id_emprendimiento = e.id_emprendimiento
    WHERE h.id_horario = $1
      AND e.id_emprendedora = $2;
`, [idHorario, req.session.idEmprendedora]);

// Rechazamos horarios inexistentes o de otros emprendimientos.
if (propiedad.rows.length === 0) {
    return res.status(404).json({
        mensaje: "El horario no existe"
    });
}

// Guardamos los datos actuales para utilizarlos al editar.
const horarioActual = propiedad.rows[0];

// No permitimos editar horarios desactivados.
if (horarioActual.activo === false) {
    return res.status(409).json({
        mensaje: "No puedes editar un horario desactivado"
    });
}

       // Recibimos los datos que la emprendedora desea modificar.
const {
    dia_semana,
    hora_inicio,
    hora_fin
} = req.body || {};

// Si no se envía un campo, conservamos su valor actual.
const nuevoDia = dia_semana === undefined
    ? horarioActual.dia_semana
    : dia_semana;

const nuevaHoraInicio = hora_inicio === undefined
    ? horarioActual.hora_inicio
    : hora_inicio;

const nuevaHoraFin = hora_fin === undefined
    ? horarioActual.hora_fin
    : hora_fin;

// Definimos los días de atención válidos.
const diasValidos = [
    "lunes",
    "martes",
    "miercoles",
    "jueves",
    "viernes",
    "sabado",
    "domingo"
];

// Validamos el día.
if (
    typeof nuevoDia !== "string" ||
    !diasValidos.includes(nuevoDia.trim().toLowerCase())
) {
    return res.status(400).json({
        mensaje: "Debes indicar un día de la semana válido"
    });
}

const diaSemanaLimpio = nuevoDia.trim().toLowerCase();

// Validamos el formato de las horas.
const formatoHora = /^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/;

if (
    typeof nuevaHoraInicio !== "string" ||
    typeof nuevaHoraFin !== "string" ||
    !formatoHora.test(nuevaHoraInicio) ||
    !formatoHora.test(nuevaHoraFin)
) {
    return res.status(400).json({
        mensaje: "Las horas deben tener formato HH:MM o HH:MM:SS"
    });
}

// Normalizamos las horas.
const horaInicioLimpia = nuevaHoraInicio.length === 5
    ? `${nuevaHoraInicio}:00`
    : nuevaHoraInicio;

const horaFinLimpia = nuevaHoraFin.length === 5
    ? `${nuevaHoraFin}:00`
    : nuevaHoraFin;

// La hora de término debe ser posterior a la de inicio.
if (horaFinLimpia <= horaInicioLimpia) {
    return res.status(400).json({
        mensaje: "La hora de término debe ser posterior a la hora de inicio"
    });
}

// Comprobamos que el nuevo horario no se superponga
// con otro horario activo de la misma trabajadora.
const superposicion = await pool.query(`
    SELECT id_horario
    FROM horario_atencion
    WHERE id_trabajadora = $1
      AND dia_semana = $2
      AND activo = TRUE
      AND id_horario <> $3
      AND hora_inicio < $5::time
      AND hora_fin > $4::time
    LIMIT 1;
`, [
    horarioActual.id_trabajadora,
    diaSemanaLimpio,
    idHorario,
    horaInicioLimpia,
    horaFinLimpia
]);

// Rechazamos la edición si encontramos un conflicto.
if (superposicion.rows.length > 0) {
    return res.status(409).json({
        mensaje: "El horario modificado se superpone con otro horario de la trabajadora"
    });
}

// Actualizamos el horario en PostgreSQL.
const resultado = await pool.query(`
    UPDATE horario_atencion
    SET
        dia_semana = $1,
        hora_inicio = $2::time,
        hora_fin = $3::time
    WHERE id_horario = $4
      AND activo = TRUE
      AND EXISTS (
          SELECT 1
          FROM trabajadora t
          INNER JOIN emprendimiento e
              ON t.id_emprendimiento = e.id_emprendimiento
          WHERE t.id_trabajadora = horario_atencion.id_trabajadora
            AND e.id_emprendedora = $5
      )
    RETURNING
        id_horario,
        id_trabajadora,
        dia_semana,
        hora_inicio,
        hora_fin,
        activo;
`, [
    diaSemanaLimpio,
    horaInicioLimpia,
    horaFinLimpia,
    idHorario,
    req.session.idEmprendedora
]);

// Comprobamos que el horario haya sido actualizado.
if (resultado.rows.length === 0) {
    return res.status(404).json({
        mensaje: "El horario no está disponible para edición"
    });
}

// Confirmamos la modificación.
return res.status(200).json({
    mensaje: "Horario actualizado correctamente",
    horario: resultado.rows[0]
});

    } catch (error) {
    // Detectamos conflictos de horarios desde PostgreSQL.
    if (error.code === "23P01") {
        return res.status(409).json({
            mensaje: "El horario modificado se superpone con otro horario de la trabajadora"
        });
    }

    console.error("Error al editar horario:", error.message);

    return res.status(500).json({
        mensaje: "No se pudo editar el horario"
    });
}
});


// Ruta para desactivar horarios de atención del Back Office.
app.patch("/api/horarios/:id/desactivar", verificarSesion, async (req, res) => {
    try {
        // Obtenemos el identificador del horario.
        const idHorario = Number(req.params.id);

        // Validamos el identificador.
        if (!Number.isSafeInteger(idHorario) || idHorario <= 0) {
            return res.status(400).json({
                mensaje: "Debes indicar un horario válido"
            });
        }

      // Buscamos el horario y verificamos que pertenezca
// a un emprendimiento de la emprendedora autenticada.
const propiedad = await pool.query(`
    SELECT
        h.id_horario,
        h.id_trabajadora,
        h.activo
    FROM horario_atencion h
    INNER JOIN trabajadora t
        ON h.id_trabajadora = t.id_trabajadora
    INNER JOIN emprendimiento e
        ON t.id_emprendimiento = e.id_emprendimiento
    WHERE h.id_horario = $1
      AND e.id_emprendedora = $2;
`, [
    idHorario,
    req.session.idEmprendedora
]);




// Rechazamos horarios inexistentes o de otros emprendimientos.
if (propiedad.rows.length === 0) {
    return res.status(404).json({
        mensaje: "El horario no existe"
    });
}

// Comprobamos si el horario ya está desactivado.
if (propiedad.rows[0].activo === false) {
    return res.status(409).json({
        mensaje: "El horario ya está desactivado"
    });
}

        // Desactivamos el horario sin eliminarlo de PostgreSQL.
const resultado = await pool.query(`
    UPDATE horario_atencion
    SET activo = FALSE
    WHERE id_horario = $1
      AND activo = TRUE
      AND EXISTS (
          SELECT 1
          FROM trabajadora t
          INNER JOIN emprendimiento e
              ON t.id_emprendimiento = e.id_emprendimiento
          WHERE t.id_trabajadora = horario_atencion.id_trabajadora
            AND e.id_emprendedora = $2
      )
    RETURNING
        id_horario,
        id_trabajadora,
        dia_semana,
        hora_inicio,
        hora_fin,
        activo;
`, [
    idHorario,
    req.session.idEmprendedora
]);

// Comprobamos que la desactivación se haya realizado.
if (resultado.rows.length === 0) {
    return res.status(409).json({
        mensaje: "El horario no está disponible para desactivación"
    });
}

// Confirmamos la desactivación.
return res.status(200).json({
    mensaje: "Horario desactivado correctamente",
    horario: resultado.rows[0]
});

    } catch (error) {
        console.error("Error al desactivar horario:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo desactivar el horario"
        });
    }
});
 // Fin de la ruta para desactivar horarios


// ============================================================
// REGISTRAR BLOQUEOS DE HORARIOS DEL BACK OFFICE
// ============================================================


// Registrar bloqueos de horarios del Back Office.
// Utiliza la misma protección de concurrencia que las reservas.
app.post("/api/bloqueos", verificarSesion, async (req, res) => {
    if(Object.keys(req.body||{}).some(campo=>!['id_trabajadora','fecha_inicio','fecha_fin','motivo'].includes(campo))){
        return res.status(400).json({mensaje:'La solicitud contiene campos de bloqueo no permitidos'});
    }
    const { id_trabajadora, fecha_inicio, fecha_fin, motivo } = req.body || {};

    const idTrabajadora = Number(id_trabajadora);

    if (!Number.isSafeInteger(idTrabajadora) || idTrabajadora <= 0) {
        return res.status(400).json({
            mensaje: "Debes indicar una trabajadora válida"
        });
    }

    const formatoFecha = /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d$/;

    const fechaValida = (valor) => {
        if (typeof valor !== "string" || !formatoFecha.test(valor)) {
            return false;
        }

        const fecha = new Date(valor + ":00Z");

        return !Number.isNaN(fecha.getTime()) &&
            fecha.toISOString().slice(0, 16) === valor;
    };

    if (!fechaValida(fecha_inicio) || !fechaValida(fecha_fin)) {
        return res.status(400).json({
            mensaje: "Las fechas deben ser válidas y tener formato AAAA-MM-DDTHH:MM"
        });
    }

    if (fecha_fin <= fecha_inicio) {
        return res.status(400).json({
            mensaje: "La fecha de término debe ser posterior al inicio"
        });
    }

    if (
        motivo !== undefined &&
        motivo !== null &&
        (typeof motivo !== "string" || motivo.length > 255)
    ) {
        return res.status(400).json({
            mensaje: "El motivo no debe superar 255 caracteres"
        });
    }

    let clienteDB;

    try {
        clienteDB = await pool.connect();
        await clienteDB.query("BEGIN");

        // Es el mismo bloqueo utilizado en POST /api/reservas.
        // Evita que ambas operaciones se ejecuten simultáneamente
        // para la misma trabajadora.
        await clienteDB.query(
            "SELECT pg_advisory_xact_lock(117, $1)",
            [idTrabajadora]
        );

        // Verificar que la trabajadora sea del emprendimiento autenticado.
        const propiedad = await clienteDB.query(`
            SELECT t.id_trabajadora
            FROM trabajadora t
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            WHERE t.id_trabajadora = $1
              AND e.id_emprendedora = $2
              AND t.activa = TRUE;
        `, [idTrabajadora, req.session.idEmprendedora]);

        if (propiedad.rows.length === 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(404).json({
                mensaje: "No se encontró una trabajadora activa de tu emprendimiento"
            });
        }

        // Evitar bloqueos superpuestos.
        const superposicion = await clienteDB.query(`
            SELECT id_bloqueo
            FROM bloqueo_horario
            WHERE id_trabajadora = $1
              AND fecha_inicio < $3::timestamp
              AND fecha_fin > $2::timestamp
            LIMIT 1;
        `, [idTrabajadora, fecha_inicio, fecha_fin]);

        if (superposicion.rows.length > 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "La trabajadora ya tiene un bloqueo que se superpone con estas fechas"
            });
        }

        // Impedir bloqueos sobre reservas activas.
        const reservas = await clienteDB.query(`
            SELECT id_reserva
            FROM reserva
            WHERE id_trabajadora = $1
              AND estado IN ('pendiente_abono', 'confirmada')
              AND fecha_hora_inicio < $3::timestamp
              AND fecha_hora_fin > $2::timestamp
            LIMIT 1;
        `, [idTrabajadora, fecha_inicio, fecha_fin]);

        if (reservas.rows.length > 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "No puedes bloquear este período porque existen reservas activas"
            });
        }

        // Crear el bloqueo dentro de la misma transacción.
        const resultado = await clienteDB.query(`
            INSERT INTO bloqueo_horario (
                id_trabajadora,
                fecha_inicio,
                fecha_fin,
                motivo
            )
            VALUES ($1, $2::timestamp, $3::timestamp, $4)
            RETURNING
                id_bloqueo,
                id_trabajadora,
                fecha_inicio,
                fecha_fin,
                motivo;
        `, [
            idTrabajadora,
            fecha_inicio,
            fecha_fin,
            motivo?.trim() || null
        ]);

        await clienteDB.query("COMMIT");

        return res.status(201).json({
            mensaje: "Bloqueo registrado correctamente",
            bloqueo: resultado.rows[0]
        });

    } catch (error) {
        if (clienteDB) {
            try {
                await clienteDB.query("ROLLBACK");
            } catch (errorRollback) {
                console.error(
                    "Error al revertir bloqueo:",
                    errorRollback.message
                );
            }
        }

        console.error("Error al registrar bloqueo:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar el bloqueo"
        });

    } finally {
        if (clienteDB) {
            clienteDB.release();
        }
    }
});






app.get("/api/mis-bloqueos", verificarSesion, async (req, res) => {
    try {
        // Consultamos los bloqueos de las trabajadoras
        // pertenecientes a los emprendimientos de la sesión.
        const resultado = await pool.query(`
            SELECT
                b.id_bloqueo,
                b.id_trabajadora,
                t.nombre AS trabajadora,
                t.id_emprendimiento,
                e.nombre AS emprendimiento,
                TO_CHAR(
                    b.fecha_inicio,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS fecha_inicio,
                TO_CHAR(
                    b.fecha_fin,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS fecha_fin,
                b.motivo
            FROM bloqueo_horario b
            INNER JOIN trabajadora t
                ON b.id_trabajadora = t.id_trabajadora
            INNER JOIN emprendimiento e
                ON t.id_emprendimiento = e.id_emprendimiento
            WHERE e.id_emprendedora = $1
            ORDER BY b.fecha_inicio, b.id_bloqueo;
        `, [req.session.idEmprendedora]);

        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar bloqueos:", error.message);

        return res.status(500).json({
            mensaje: "No se pudieron consultar los bloqueos"
        });
    }
});


// ============================================================
// ELIMINAR BLOQUEOS DE HORARIOS DEL BACK OFFICE
// ============================================================

app.delete("/api/bloqueos/:id", verificarSesion, async (req, res) => {
    try {
        // Identificamos el bloqueo que se desea eliminar.
        const idBloqueo = Number(req.params.id);

        // Validamos el identificador.
        if (!Number.isSafeInteger(idBloqueo) || idBloqueo <= 0) {
            return res.status(400).json({
                mensaje: "El identificador del bloqueo no es válido"
            });
        }

        // Eliminamos únicamente bloqueos pertenecientes
        // a trabajadoras de los emprendimientos de la sesión.
        const resultado = await pool.query(`
            DELETE FROM bloqueo_horario b
            WHERE b.id_bloqueo = $1
              AND EXISTS (
                  SELECT 1
                  FROM trabajadora t
                  INNER JOIN emprendimiento e
                      ON t.id_emprendimiento = e.id_emprendimiento
                  WHERE t.id_trabajadora = b.id_trabajadora
                    AND e.id_emprendedora = $2
              )
            RETURNING
                b.id_bloqueo,
                b.id_trabajadora,
                b.fecha_inicio,
                b.fecha_fin,
                b.motivo;
        `, [
            idBloqueo,
            req.session.idEmprendedora
        ]);

        // Si no se eliminó ningún bloqueo, devolvemos 404.
        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El bloqueo no existe"
            });
        }

        // Confirmamos la eliminación.
        return res.status(200).json({
            mensaje: "Bloqueo eliminado correctamente",
            bloqueo: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al eliminar bloqueo:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo eliminar el bloqueo"
        });
    }
});








// Ruta para registrar nuevas trabajadoras en Meraki.
// Solo las emprendedoras autenticadas pueden registrar trabajadoras.
app.post("/api/trabajadoras", verificarSesion, async (req, res) => {
    try {
        const permitidos = ['id_emprendimiento','nombre','apellido','descripcion'];
        if (Object.keys(req.body || {}).some(campo => !permitidos.includes(campo))) {
            return res.status(400).json({mensaje:'La solicitud contiene campos de trabajadora no permitidos'});
        }

        // Recibimos los datos de la trabajadora.
        const {
            id_emprendimiento,
            nombre,
            apellido,
            descripcion
        } = req.body || {};

        // Convertimos el identificador del emprendimiento a número.
const idEmprendimiento = Number(id_emprendimiento);

// Comprobamos que sea un entero positivo.
if (
    !Number.isSafeInteger(idEmprendimiento) ||
    idEmprendimiento <= 0
) {
    return res.status(400).json({
        mensaje: "Debes indicar un emprendimiento válido"
    });
}


// ============================================================
// CONSULTAR BLOQUEOS DE HORARIOS DEL BACK OFFICE
// ============================================================







// Verificamos que el emprendimiento pertenezca
// a la emprendedora que inició sesión.
const propiedad = await pool.query(`
    SELECT id_emprendimiento
    FROM emprendimiento
    WHERE id_emprendimiento = $1
      AND id_emprendedora = $2;
`, [idEmprendimiento, req.session.idEmprendedora]);

// Impedimos registrar trabajadoras en emprendimientos ajenos.
if (propiedad.rows.length === 0) {
    return res.status(403).json({
        mensaje: "No tienes permiso para registrar trabajadoras en este emprendimiento"
    });
}

// Validamos que el nombre sea obligatorio y no supere 100 caracteres.
if (
    typeof nombre !== "string" ||
    nombre.trim() === "" ||
    nombre.trim().length > 100
) {
    return res.status(400).json({
        mensaje: "El nombre debe tener entre 1 y 100 caracteres"
    });
}

// Validamos el apellido, que es opcional.
if (
    apellido != null &&
    (
        typeof apellido !== "string" ||
        apellido.trim().length > 100
    )
) {
    return res.status(400).json({
        mensaje: "El apellido no debe superar 100 caracteres"
    });
}

// Validamos la descripción, que también es opcional.
if (
    descripcion != null &&
    (
        typeof descripcion !== "string" ||
        descripcion.length > 1000
    )
) {
    return res.status(400).json({
        mensaje: "La descripción no debe superar 1000 caracteres"
    });
}

// Preparamos los datos para guardarlos en PostgreSQL.
const nombreLimpio = nombre.trim();
const apellidoLimpio = apellido?.trim() || null;
const descripcionLimpia = descripcion?.trim() || null;

// Registramos la trabajadora en PostgreSQL.
const resultado = await pool.query(`
    INSERT INTO trabajadora (
        id_emprendimiento,
        nombre,
        apellido,
        descripcion
    )
    VALUES ($1, $2, $3, $4)
    RETURNING
        id_trabajadora,
        id_emprendimiento,
        nombre,
        apellido,
        descripcion,
        activa;
`, [
    idEmprendimiento,
    nombreLimpio,
    apellidoLimpio,
    descripcionLimpia
]);


// Confirmamos que la trabajadora fue registrada.
return res.status(201).json({
    mensaje: "Trabajadora registrada correctamente",
    trabajadora: resultado.rows[0]
});

    } catch (error) {
        console.error("Error al registrar trabajadora:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar la trabajadora"
        });
    }
});

// Ruta para modificar los datos de una trabajadora del Back Office.
// Solo las emprendedoras autenticadas pueden modificar trabajadoras.
app.patch("/api/trabajadoras/:id", verificarSesion, async (req, res) => {
    try {
        const permitidos = ['nombre','apellido','descripcion'];
        if (Object.keys(req.body || {}).some(campo => !permitidos.includes(campo))) {
            return res.status(400).json({mensaje:'La solicitud contiene campos de trabajadora no permitidos'});
        }
        // Obtenemos el identificador de la trabajadora.
        const idTrabajadora = Number(req.params.id);

        // Comprobamos que sea un número entero positivo.
        if (
            !Number.isSafeInteger(idTrabajadora) ||
            idTrabajadora <= 0
        ) {
            return res.status(400).json({
                mensaje: "El identificador de la trabajadora no es válido"
            });
        }

        // Verificamos que la trabajadora pertenezca a un
// emprendimiento de la emprendedora autenticada.
const propiedad = await pool.query(`
    SELECT t.id_trabajadora
    FROM trabajadora t
    INNER JOIN emprendimiento e
        ON t.id_emprendimiento = e.id_emprendimiento
    WHERE t.id_trabajadora = $1
      AND e.id_emprendedora = $2;
`, [idTrabajadora, req.session.idEmprendedora]);

// Si no existe o no pertenece a su negocio, rechazamos la edición.
if (propiedad.rows.length === 0) {
    return res.status(404).json({
        mensaje: "La trabajadora no existe"
    });
}

// Recibimos los datos que la emprendedora desea modificar.
const {
    nombre,
    apellido,
    descripcion
} = req.body || {};

// Comprobamos que se haya enviado al menos un campo editable.
if (
    nombre === undefined &&
    apellido === undefined &&
    descripcion === undefined
) {
    return res.status(400).json({
        mensaje: "Debes indicar al menos un campo para modificar"
    });
}

// Validamos el nombre solamente si fue enviado.
if (nombre !== undefined) {
    if (
        typeof nombre !== "string" ||
        nombre.trim() === "" ||
        nombre.trim().length > 100
    ) {
        return res.status(400).json({
            mensaje: "El nombre debe tener entre 1 y 100 caracteres"
        });
    }
}

// Validamos el apellido si fue enviado.
// También permitimos null para quitar el apellido.
if (
    apellido !== undefined &&
    apellido !== null &&
    (
        typeof apellido !== "string" ||
        apellido.trim().length > 100
    )
) {
    return res.status(400).json({
        mensaje: "El apellido no debe superar 100 caracteres"
    });
}

// Validamos la descripción si fue enviada.
// También permitimos null para quitar la descripción.
if (
    descripcion !== undefined &&
    descripcion !== null &&
    (
        typeof descripcion !== "string" ||
        descripcion.length > 1000
    )
) {
    return res.status(400).json({
        mensaje: "La descripción no debe superar 1000 caracteres"
    });
}

// Actualizamos únicamente los campos enviados.
// Los demás conservarán sus valores actuales.
const resultado = await pool.query(`
    UPDATE trabajadora
    SET
        nombre = COALESCE($1::text, nombre),
        apellido = CASE
            WHEN $2::boolean THEN $3::text
            ELSE apellido
        END,
        descripcion = CASE
            WHEN $4::boolean THEN $5::text
            ELSE descripcion
        END
    WHERE id_trabajadora = $6
      AND id_emprendimiento IN (
          SELECT id_emprendimiento
          FROM emprendimiento
          WHERE id_emprendedora = $7
      )
    RETURNING
        id_trabajadora,
        id_emprendimiento,
        nombre,
        apellido,
        descripcion,
        activa;
`, [
    nombre !== undefined ? nombre.trim() : null,
    apellido !== undefined,
    apellido == null ? null : apellido.trim(),
    descripcion !== undefined,
    descripcion == null ? null : descripcion.trim(),
    idTrabajadora,
    req.session.idEmprendedora
]);

// Comprobamos que se haya actualizado la trabajadora.
if (resultado.rows.length === 0) {
    return res.status(404).json({
        mensaje: "La trabajadora no existe"
    });
}

// Devolvemos los datos actualizados al Back Office.
return res.json({
    mensaje: "Trabajadora actualizada correctamente",
    trabajadora: resultado.rows[0]
});

    } catch (error) {
        console.error("Error al modificar trabajadora:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo modificar la trabajadora"
        });
    }
});

// Ruta para desactivar trabajadoras del Back Office.
// Solo las emprendedoras autenticadas pueden desactivar trabajadoras.
app.patch("/api/trabajadoras/:id/desactivar", verificarSesion, async (req, res) => {
    try {
        // Obtenemos y validamos el identificador.
        const idTrabajadora = Number(req.params.id);

        if (!Number.isSafeInteger(idTrabajadora) || idTrabajadora <= 0) {
            return res.status(400).json({
                mensaje: "El identificador de la trabajadora no es válido"
            });
        }

        // Desactivamos únicamente trabajadoras activas
        // pertenecientes a los emprendimientos de la sesión.
        const resultado = await pool.query(`
            UPDATE trabajadora
            SET activa = FALSE
            WHERE id_trabajadora = $1
              AND activa = TRUE
              AND id_emprendimiento IN (
                  SELECT id_emprendimiento
                  FROM emprendimiento
                  WHERE id_emprendedora = $2
              )
            RETURNING
                id_trabajadora,
                id_emprendimiento,
                nombre,
                apellido,
                activa;
        `, [idTrabajadora, req.session.idEmprendedora]);

        // Si no hubo actualización, comprobamos si la trabajadora
        // existe dentro de los emprendimientos de esta cuenta.
        if (resultado.rows.length === 0) {
            const existente = await pool.query(`
                SELECT t.id_trabajadora
                FROM trabajadora t
                INNER JOIN emprendimiento e
                    ON t.id_emprendimiento = e.id_emprendimiento
                WHERE t.id_trabajadora = $1
                  AND e.id_emprendedora = $2;
            `, [idTrabajadora, req.session.idEmprendedora]);

            if (existente.rows.length === 0) {
                return res.status(404).json({
                    mensaje: "La trabajadora no existe"
                });
            }

            return res.status(409).json({
                mensaje: "La trabajadora ya está desactivada"
            });
        }

        return res.json({
            mensaje: "Trabajadora desactivada correctamente",
            trabajadora: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al desactivar trabajadora:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo desactivar la trabajadora"
        });
    }
});


// Ruta para registrar nuevos servicios en Meraki.
// Solo las emprendedoras autenticadas pueden crear servicios.
app.post("/api/servicios", verificarSesion, async (req, res) => {
    try {

        const permitidos = ['id_emprendimiento','id_categoria','nombre','descripcion','precio','duracion_min','monto_abono'];
        if (Object.keys(req.body || {}).some(campo => !permitidos.includes(campo))) {
            return res.status(400).json({mensaje:'La solicitud contiene campos de servicio no permitidos'});
        }

        // Recibimos los datos del servicio.
        const {
            id_emprendimiento,
            id_categoria,
            nombre,
            descripcion,
            precio,
            duracion_min,
            monto_abono
        } = req.body || {};

        // Convertimos el identificador del emprendimiento a número.
const idEmprendimiento = Number(id_emprendimiento);

// Comprobamos que sea un número entero positivo.
if (
    !Number.isSafeInteger(idEmprendimiento) ||
    idEmprendimiento <= 0
) {
    return res.status(400).json({
        mensaje: "Debes indicar un emprendimiento válido"
    });
}

// Comprobamos que el emprendimiento pertenezca
// a la emprendedora que inició sesión.
const propiedad = await pool.query(`
    SELECT id_emprendimiento
    FROM emprendimiento
    WHERE id_emprendimiento = $1
      AND id_emprendedora = $2;
`, [idEmprendimiento, req.session.idEmprendedora]);

// Rechazamos la operación si el emprendimiento no es suyo.
if (propiedad.rows.length === 0) {
    return res.status(403).json({
        mensaje: "No tienes permiso para crear servicios en este emprendimiento"
    });
}
// Convertimos el identificador de la categoría a número.
const idCategoria = Number(id_categoria);

// Comprobamos que sea un entero positivo.
if (!Number.isSafeInteger(idCategoria) || idCategoria <= 0) {
    return res.status(400).json({
        mensaje: "Debes indicar una categoría válida"
    });
}

// Comprobamos que la categoría exista en PostgreSQL.
const categoria = await pool.query(`
    SELECT id_categoria
    FROM categoria
    WHERE id_categoria = $1;
`, [idCategoria]);

if (categoria.rows.length === 0) {
    return res.status(400).json({
        mensaje: "La categoría indicada no existe"
    });
}

// Validamos el nombre del servicio.
if (
    typeof nombre !== "string" ||
    nombre.trim() === "" ||
    nombre.trim().length > 150
) {
    return res.status(400).json({
        mensaje: "El nombre del servicio debe tener entre 1 y 150 caracteres"
    });
}

// Preparamos el nombre sin espacios innecesarios.
const nombreLimpio = nombre.trim();
// Validamos que el precio sea un número mayor que cero.
if (
    typeof precio !== "number" ||
    !Number.isFinite(precio) ||
    precio <= 0 || precio > 99999999.99 || Number(precio.toFixed(2)) !== precio
) {
    return res.status(400).json({
        mensaje: "El precio debe ser un número mayor que cero"
    });
}

// Validamos que la duración sea un entero positivo.
if (
    !Number.isSafeInteger(duracion_min) ||
    duracion_min <= 0 || duracion_min > 2147483647
) {
    return res.status(400).json({
        mensaje: "La duración debe ser un número entero positivo"
    });
}

// Validamos que el abono no sea negativo ni supere el precio.
if (
    !abonoCLPValido(monto_abono,precio)
) {
    return res.status(400).json({
        mensaje: "El abono debe ser un entero positivo en pesos chilenos y no superar el precio del servicio"
    });
}

// Validamos la descripción opcional.
if (
    descripcion != null &&
    (typeof descripcion !== "string" || descripcion.length > 1000)
) {
    return res.status(400).json({
        mensaje: "La descripción no debe superar los 1000 caracteres"
    });
}

// Preparamos la descripción para guardarla.
const descripcionLimpia = descripcion?.trim() || null;
// Registramos el nuevo servicio en PostgreSQL.
const resultado = await pool.query(`
    INSERT INTO servicio (
        id_emprendimiento,
        id_categoria,
        nombre,
        descripcion,
        precio,
        duracion_min,
        monto_abono
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING
        id_servicio,
        id_emprendimiento,
        id_categoria,
        nombre,
        descripcion,
        precio,
        duracion_min,
        monto_abono,
        activo;
`, [
    idEmprendimiento,
    idCategoria,
    nombreLimpio,
    descripcionLimpia,
    precio,
    duracion_min,
    monto_abono
]);

// Confirmamos que el servicio fue registrado.
return res.status(201).json({
    mensaje: "Servicio registrado correctamente",
    servicio: resultado.rows[0]
});




    } catch (error) {
        console.error("Error al crear servicio:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar el servicio"
        });
    }
});


// Ruta para modificar servicios del Back Office.
// Solo las emprendedoras autenticadas pueden editar servicios.
app.patch("/api/servicios/:id", verificarSesion, async (req, res) => {
    try {

        const permitidos = ['id_categoria','nombre','descripcion','precio','duracion_min','monto_abono'];
        if (Object.keys(req.body || {}).some(campo => !permitidos.includes(campo))) {
            return res.status(400).json({mensaje:'La solicitud contiene campos de servicio no permitidos'});
        }

        // Obtenemos el identificador del servicio.
        const idServicio = Number(req.params.id);

        // Comprobamos que el identificador sea válido.
        if (!Number.isSafeInteger(idServicio) || idServicio <= 0) {
            return res.status(400).json({
                mensaje: "El identificador del servicio no es válido"
            });
        }

       // Comprobamos que el servicio pertenezca a un emprendimiento
// de la emprendedora que inició sesión.
const propiedad = await pool.query(`
    SELECT s.id_servicio
    FROM servicio s
    INNER JOIN emprendimiento e
        ON s.id_emprendimiento = e.id_emprendimiento
    WHERE s.id_servicio = $1
      AND e.id_emprendedora = $2;
`, [idServicio, req.session.idEmprendedora]);

// Si el servicio no existe o no pertenece a la emprendedora,
// no permitimos modificarlo.
if (propiedad.rows.length === 0) {
    return res.status(404).json({
        mensaje: "El servicio no existe"
    });
}

// Recibimos los campos que la emprendedora desea modificar.
const {
    id_categoria,
    nombre,
    descripcion,
    precio,
    duracion_min,
    monto_abono
} = req.body || {};

// Comprobamos que se haya enviado al menos un campo permitido.
if (
    id_categoria === undefined &&
    nombre === undefined &&
    descripcion === undefined &&
    precio === undefined &&
    duracion_min === undefined &&
    monto_abono === undefined
) {
    return res.status(400).json({
        mensaje: "Debes indicar al menos un campo para modificar"
    });
}

// La categoría también es editable, pero debe existir en el catálogo.
if (id_categoria !== undefined) {
    if (!Number.isSafeInteger(id_categoria) || id_categoria <= 0) {
        return res.status(400).json({mensaje:'Debes indicar una categoría válida'});
    }
    const categoria = await pool.query('SELECT id_categoria FROM categoria WHERE id_categoria=$1',[id_categoria]);
    if (!categoria.rows.length) return res.status(400).json({mensaje:'La categoría indicada no existe'});
}

// Validamos el nombre solamente si fue enviado.
if (nombre !== undefined) {
    if (
        typeof nombre !== "string" ||
        nombre.trim() === "" ||
        nombre.trim().length > 150
    ) {
        return res.status(400).json({
            mensaje: "El nombre del servicio debe tener entre 1 y 150 caracteres"
        });
    }
}

// Validamos la descripción solamente si fue enviada.
if (descripcion !== undefined) {
    if (
        descripcion !== null &&
        (
            typeof descripcion !== "string" ||
            descripcion.length > 1000
        )
    ) {
        return res.status(400).json({
            mensaje: "La descripción no debe superar los 1000 caracteres"
        });
    }
}

// Validamos el precio si fue enviado.
if (precio !== undefined) {
    if (
        typeof precio !== "number" ||
        !Number.isFinite(precio) ||
        precio <= 0 || precio > 99999999.99 || Number(precio.toFixed(2)) !== precio
    ) {
        return res.status(400).json({
            mensaje: "El precio debe ser un número mayor que cero"
        });
    }
}

// Validamos la duración si fue enviada.
if (duracion_min !== undefined) {
    if (
        !Number.isSafeInteger(duracion_min) ||
        duracion_min <= 0 || duracion_min > 2147483647
    ) {
        return res.status(400).json({
            mensaje: "La duración debe ser un número entero positivo"
        });
    }
}

// Validamos el abono si fue enviado.
if (monto_abono !== undefined) {
    if (
        !abonoCLPValido(monto_abono)
    ) {
        return res.status(400).json({
        mensaje: "El abono debe ser un entero positivo en pesos chilenos"
        });
    }
}

// Consultamos los valores actuales del servicio.
// Los necesitamos porque PATCH permite modificar solo algunos campos.
const servicioActual = await pool.query(`
    SELECT precio, monto_abono
    FROM servicio
    WHERE id_servicio = $1;
`, [idServicio]);

// Obtenemos los valores actuales desde PostgreSQL.
const precioActual = Number(servicioActual.rows[0].precio);
const abonoActual = Number(servicioActual.rows[0].monto_abono);

// Si enviaron un precio o abono nuevo, lo utilizamos.
// Si no, conservamos el valor que ya estaba registrado.
const precioFinal = precio !== undefined ? precio : precioActual;
const abonoFinal = monto_abono !== undefined ? monto_abono : abonoActual;

// Comprobamos que el abono no supere el precio final.
if (!abonoCLPValido(abonoFinal,precioFinal)) {
    return res.status(400).json({
        mensaje: "El abono debe ser un entero positivo en pesos chilenos y no superar el precio del servicio"
    });
}

// Actualizamos únicamente los campos enviados.
// Los demás conservan sus valores actuales.
const resultado = await pool.query(`
    UPDATE servicio
    SET
        nombre = COALESCE($1, nombre),
        descripcion = CASE
            WHEN $2::boolean THEN $3::text
            ELSE descripcion
        END,
        precio = COALESCE($4, precio),
        duracion_min = COALESCE($5, duracion_min),
        monto_abono = COALESCE($6, monto_abono),
        id_categoria = COALESCE($9, id_categoria)
    WHERE id_servicio = $7
      -- Se evalúa contra la fila vigente, incluso si hubo otra edición simultánea.
      AND COALESCE($6, monto_abono) <= COALESCE($4, precio)
      AND COALESCE($6, monto_abono) BETWEEN 1 AND 99999999
      AND COALESCE($6, monto_abono) = trunc(COALESCE($6, monto_abono))
      AND id_emprendimiento IN (
          SELECT id_emprendimiento
          FROM emprendimiento
          WHERE id_emprendedora = $8
      )
    RETURNING
        id_servicio,
        id_emprendimiento,
        id_categoria,
        nombre,
        descripcion,
        precio,
        duracion_min,
        monto_abono,
        activo;
`, [
    nombre !== undefined ? nombre.trim() : null,
    descripcion !== undefined,
    descripcion == null ? null : descripcion.trim(),
    precio !== undefined ? precio : null,
    duracion_min !== undefined ? duracion_min : null,
    monto_abono !== undefined ? monto_abono : null,
    idServicio,
    req.session.idEmprendedora,
    id_categoria ?? null
]);

// Comprobamos que el servicio haya sido actualizado.
if (resultado.rows.length === 0) {
    return res.status(409).json({
        mensaje: "El servicio cambió durante la edición. Actualiza la lista y revisa el precio y el abono"
    });
}

// Respondemos con los datos actualizados.
return res.json({
    mensaje: "Servicio actualizado correctamente",
    servicio: resultado.rows[0]
});

    } catch (error) {
        console.error("Error al modificar servicio:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo modificar el servicio"
        });
    }
});



// Reactivar un servicio propio sin modificar sus demás datos.
app.patch('/api/servicios/:id/activar', verificarSesion, async(req,res)=>{
    if(req.get('Sec-Fetch-Site')==='cross-site'||(req.get('Origin')&&req.get('Origin')!==req.protocol+'://'+req.get('Host')))return res.status(403).json({mensaje:'Solicitud no autorizada'});
    const id=Number(req.params.id);
    if(!Number.isSafeInteger(id)||id<=0)return res.status(400).json({mensaje:'El identificador del servicio no es válido'});
    if(Object.keys(req.body||{}).length)return res.status(400).json({mensaje:'La activación no admite cambios de otros campos'});
    try{
        const r=await pool.query(`UPDATE servicio SET activo=TRUE
          WHERE id_servicio=$1 AND activo=FALSE
          AND id_emprendimiento IN (SELECT id_emprendimiento FROM emprendimiento WHERE id_emprendedora=$2)
          RETURNING id_servicio,nombre,activo`,[id,req.session.idEmprendedora]);
        if(r.rows.length)return res.json({mensaje:'Servicio activado correctamente',servicio:r.rows[0]});
        const propio=await pool.query(`SELECT s.id_servicio FROM servicio s JOIN emprendimiento e USING(id_emprendimiento)
          WHERE s.id_servicio=$1 AND e.id_emprendedora=$2`,[id,req.session.idEmprendedora]);
        return res.status(propio.rows.length?409:404).json({mensaje:propio.rows.length?'El servicio ya está activo':'El servicio no existe'});
    }catch(error){return res.status(500).json({mensaje:'No se pudo activar el servicio'});}
});

 // Ruta para desactivar servicios del Back Office.
 // Solo las emprendedoras autenticadas pueden desactivar sus servicios.
 app.patch("/api/servicios/:id/desactivar", verificarSesion, async (req, res) => {
     try {
         // Obtenemos el identificador del servicio.
         const idServicio = Number(req.params.id);

         // Comprobamos que sea un identificador válido.
         if (!Number.isSafeInteger(idServicio) || idServicio <= 0) {
             return res.status(400).json({
                 mensaje: "El identificador del servicio no es válido"
             });
         }

         // Desactivamos únicamente un servicio activo
         // perteneciente a la emprendedora autenticada.
         const resultado = await pool.query(`
             UPDATE servicio
             SET activo = FALSE
             WHERE id_servicio = $1
               AND activo = TRUE
               AND id_emprendimiento IN (
                   SELECT id_emprendimiento
                   FROM emprendimiento
                   WHERE id_emprendedora = $2
               )
             RETURNING id_servicio, nombre, activo;
         `, [idServicio, req.session.idEmprendedora]);

         // Si no se actualizó, comprobamos si pertenece a la emprendedora.
         if (resultado.rows.length === 0) {
             const existente = await pool.query(`
                 SELECT s.id_servicio
                 FROM servicio s
                 INNER JOIN emprendimiento e
                     ON s.id_emprendimiento = e.id_emprendimiento
                 WHERE s.id_servicio = $1
                   AND e.id_emprendedora = $2;
             `, [idServicio, req.session.idEmprendedora]);

             if (existente.rows.length === 0) {
                 return res.status(404).json({
                     mensaje: "El servicio no existe"
                 });
             }

             return res.status(409).json({
                 mensaje: "El servicio ya está desactivado"
             });
         }

         return res.json({
             mensaje: "Servicio desactivado correctamente",
             servicio: resultado.rows[0]
         });

     } catch (error) {
         console.error("Error al desactivar servicio:", error.message);

         return res.status(500).json({
             mensaje: "No se pudo desactivar el servicio"
         });
     }
 });




// Ruta para consultar los horarios de atención.
app.get("/api/disponibilidad", async (req, res) => {
    try {
         // Obtenemos la fecha enviada por el navegador.
        const fecha = req.query.fecha;
        // Obtenemos los identificadores enviados desde el navegador.
const idTrabajadora = Number(req.query.id_trabajadora);
const idServicio = Number(req.query.id_servicio);

// Comprobamos que sean números enteros positivos.
if (
    !Number.isSafeInteger(idTrabajadora) ||
    idTrabajadora <= 0 ||
    !Number.isSafeInteger(idServicio) ||
    idServicio <= 0
) {
    return res.status(400).json({
        mensaje: "Debes indicar una trabajadora y un servicio válidos"
    });
}

        // Mostramos la fecha recibida para comprobarla.
        console.log("Fecha solicitada:", fecha);

         // Comprobamos que la fecha tenga el formato AAAA-MM-DD.
        if (typeof fecha !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
            return res.status(400).json({
                mensaje: "Debes indicar una fecha con formato AAAA-MM-DD"
            });
        }

        // Convertimos la fecha recibida en un objeto Date.
        const fechaConvertida = new Date(fecha + "T00:00:00Z");

        // Comprobamos que la fecha exista realmente.
        if (
            Number.isNaN(fechaConvertida.getTime()) ||
            fechaConvertida.toISOString().slice(0, 10) !== fecha
        ) {
            return res.status(400).json({
                mensaje: "La fecha indicada no existe"
            });
        }
        // Obtenemos el número del día de la semana.
        // JavaScript utiliza: 0 = domingo, 1 = lunes, ..., 6 = sábado.
    const numeroDia = fechaConvertida.getUTCDay();

    // Relacionamos cada número con el nombre del día.
    const diasSemana = [
    "domingo",
    "lunes",
    "martes",
    "miercoles",
    "jueves",
    "viernes",
    "sabado"
];

// Obtenemos el nombre del día correspondiente a la fecha.
    const diaSemana = diasSemana[numeroDia];

// Mostramos el día para comprobar el resultado.
    console.log("Día solicitado:", diaSemana);
        
        
// Consultamos los horarios disponibles según la trabajadora,
// el servicio y la fecha seleccionados.
const resultado = await pool.query(`
    SELECT
        t.id_trabajadora,
        t.nombre AS trabajadora,
        s.id_servicio,
        s.nombre AS servicio,
        horas.hora::TIME AS hora_inicio
    FROM trabajadora t

    INNER JOIN horario_atencion h
        ON t.id_trabajadora = h.id_trabajadora

    INNER JOIN trabajadora_servicio ts
        ON t.id_trabajadora = ts.id_trabajadora

    INNER JOIN servicio s
        ON ts.id_servicio = s.id_servicio

    -- Generamos los horarios según la duración del servicio.
    CROSS JOIN LATERAL generate_series(
        $1::DATE + h.hora_inicio,
        $1::DATE + h.hora_fin
            - s.duracion_min * INTERVAL '1 minute',
        s.duracion_min * INTERVAL '1 minute'
    ) AS horas(hora)

    WHERE t.id_trabajadora = $3
      AND s.id_servicio = $4
      AND h.dia_semana = $2
      AND h.activo = TRUE
      AND t.activa = TRUE
      AND s.activo = TRUE

    -- Excluimos los horarios bloqueados.
    AND NOT EXISTS (
        SELECT 1
        FROM bloqueo_horario b
        WHERE b.id_trabajadora = t.id_trabajadora
          AND horas.hora < b.fecha_fin
          AND horas.hora + s.duracion_min * INTERVAL '1 minute'
              > b.fecha_inicio
    )

    -- Excluimos los horarios que ya tienen reservas.
    AND NOT EXISTS (
        SELECT 1
        FROM reserva r
        WHERE r.id_trabajadora = t.id_trabajadora
          AND r.estado IN ('pendiente_abono', 'confirmada')
          AND horas.hora < r.fecha_hora_fin
          AND horas.hora + s.duracion_min * INTERVAL '1 minute'
              > r.fecha_hora_inicio
    )

    ORDER BY horas.hora;
`, [fecha, diaSemana, idTrabajadora, idServicio]);
// Enviamos los resultados al navegador.
        res.json(resultado.rows);

    } catch (error) {
        // Mostramos el error en la terminal.
        console.error("Error al consultar horarios:", error.message);

        // Respondemos si ocurre un error.
        res.status(500).json({
            mensaje: "Error al consultar la disponibilidad"
        });
    }
});




// Registrar nuevas clientas desde el Front Office.
app.post("/api/clientas", verificarSesion, async (req, res) => {
    try {
        const { nombre, correo, telefono } = req.body || {};

        // Validar los campos obligatorios.
        if (
            typeof nombre !== "string" ||
            typeof correo !== "string" ||
            nombre.trim() === "" ||
            correo.trim() === ""
        ) {
            return res.status(400).json({
                mensaje: "El nombre y el correo son obligatorios"
            });
        }

        const nombreLimpio = nombre.trim();
        const correoLimpio = correo.trim().toLowerCase();

        // Validar la longitud de los campos.
        if (
            nombreLimpio.length > 100 ||
            correoLimpio.length > 150 ||
            (telefono != null &&
                (typeof telefono !== "string" || telefono.trim().length > 20))
        ) {
            return res.status(400).json({
                mensaje: "Uno o más campos son inválidos o demasiado largos"
            });
        }

        // Validar el formato del correo electrónico.
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correoLimpio)) {
            return res.status(400).json({
                mensaje: "El correo electrónico no tiene un formato válido"
            });
        }

        const telefonoLimpio = telefono?.trim() || null;

        // Registrar la clienta en PostgreSQL.
        const resultado = await pool.query(`
            INSERT INTO clienta (nombre, correo, telefono)
            VALUES ($1, $2, $3)
            ON CONFLICT (LOWER(TRIM(correo))) DO NOTHING
            RETURNING id_clienta;
        `, [
            nombreLimpio,
            correoLimpio,
            telefonoLimpio
        ]);

        // Una clienta puede reservar de nuevo sin duplicar su perfil.
        // No sobrescribimos su nombre ni teléfono desde una solicitud pública.
        const clienta = resultado.rows[0] || (await pool.query(
            "SELECT id_clienta FROM clienta WHERE LOWER(TRIM(correo)) = $1",
            [correoLimpio]
        )).rows[0];
        if (!clienta) throw new Error("No se pudieron recuperar los datos de la clienta");
        return res.status(resultado.rows.length ? 201 : 200).json({
            mensaje: "Datos de clienta recibidos correctamente",
            id_clienta: clienta.id_clienta
        });

    } catch (error) {
        // Evitar registros con correos duplicados.
        if (error.code === "23505") {
            return res.status(409).json({
                mensaje: "No se pudo completar el registro con los datos proporcionados"
            });
        }

        console.error("Error al registrar clienta:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar la clienta"
        });
    }
});




// Ruta para registrar nuevas reservas en Meraki.
app.post("/api/reservas", verificarSesion, async (req, res) => {

    const nombreReserva = req.body?.nombre_clienta;
    if (nombreReserva !== undefined && (typeof nombreReserva !== 'string' || !nombreReserva.trim() || nombreReserva.trim().length > 200)) {
        return res.status(400).json({mensaje:'Indica un nombre de hasta 200 caracteres para la reserva'});
    }

    // Recibimos los datos enviados por la clienta.
    const {
        id_clienta,
        id_trabajadora,
        id_servicio,
        fecha,
        hora
    } = req.body || {};

    // Convertimos los identificadores a números.
    const idClienta = Number(id_clienta);
    const idTrabajadora = Number(id_trabajadora);
    const idServicio = Number(id_servicio);

    // Validamos que los identificadores sean enteros positivos.
    if (
        ![idClienta, idTrabajadora, idServicio].every(
            id => Number.isSafeInteger(id) && id > 0
        )
    ) {
        return res.status(400).json({
            mensaje: "Los identificadores deben ser números positivos"
        });
    }

    // Validamos el formato de la fecha.
    if (
        typeof fecha !== "string" ||
        !/^\d{4}-\d{2}-\d{2}$/.test(fecha)
    ) {
        return res.status(400).json({
            mensaje: "La fecha debe tener formato AAAA-MM-DD"
        });
    }

    // Comprobamos que la fecha exista realmente.
    const fechaConvertida = new Date(fecha + "T00:00:00Z");

    if (
        Number.isNaN(fechaConvertida.getTime()) ||
        fechaConvertida.toISOString().slice(0, 10) !== fecha
    ) {
        return res.status(400).json({
            mensaje: "La fecha indicada no existe"
        });
    }

    // Validamos la hora en formato HH:MM.
    if (
        typeof hora !== "string" ||
        !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(hora)
    ) {
        return res.status(400).json({
            mensaje: "La hora debe tener formato HH:MM"
        });
    }

    // Identificamos el día de la semana.
    const diasSemana = [
        "domingo", "lunes", "martes", "miercoles",
        "jueves", "viernes", "sabado"
    ];

    const diaSemana = diasSemana[fechaConvertida.getUTCDay()];

    // Solicitamos una conexión exclusiva para esta transacción.
    let clienteDB;

    try {
        clienteDB = await pool.connect();

        // Comenzamos la transacción.
        await clienteDB.query("BEGIN");

        // Bloqueamos temporalmente las reservas de esta trabajadora.
        // Así, dos solicitudes de esta ruta no podrán reservar
        // simultáneamente un mismo horario.
        await clienteDB.query(
            "SELECT pg_advisory_xact_lock(117, $1)",
            [idTrabajadora]
        );

        const propietaria=await clienteDB.query('SELECT 1 FROM servicio s JOIN emprendimiento e USING(id_emprendimiento) WHERE s.id_servicio=$1 AND e.id_emprendedora=$2',[idServicio,req.session.idEmprendedora]);
        if(!propietaria.rowCount){await clienteDB.query('ROLLBACK');return res.status(404).json({mensaje:'Servicio no disponible'});}
        // Comprobamos que la clienta exista.
        const clienta = await clienteDB.query(
            "SELECT id_clienta FROM clienta WHERE id_clienta = $1",
            [idClienta]
        );

        if (clienta.rows.length === 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(404).json({
                mensaje: "La clienta no existe"
            });
        }

        // Impedimos reservar fechas u horas que ya pasaron.
        // Utilizamos la zona horaria de Chile.
        const fechaFutura = await clienteDB.query(`
            SELECT (
                $1::DATE + $2::TIME
                > CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago'
            ) AS es_futura
        `, [fecha, hora]);

        if (!fechaFutura.rows[0].es_futura) {
            await clienteDB.query("ROLLBACK");

            return res.status(400).json({
                mensaje: "No puedes reservar una fecha u hora pasada"
            });
        }

        // Comprobamos que la hora solicitada esté disponible.
        // También obtenemos los datos del servicio desde PostgreSQL.
        const disponibilidad = await clienteDB.query(`
            SELECT
                s.id_emprendimiento,
                s.id_servicio,
                s.precio,
                s.monto_abono,
                horas.hora AS fecha_hora_inicio,
                horas.hora
                    + s.duracion_min * INTERVAL '1 minute'
                    AS fecha_hora_fin

            FROM trabajadora t

            INNER JOIN horario_atencion h
                ON t.id_trabajadora = h.id_trabajadora

            INNER JOIN trabajadora_servicio ts
                ON t.id_trabajadora = ts.id_trabajadora

            INNER JOIN servicio s
                ON ts.id_servicio = s.id_servicio

            INNER JOIN emprendimiento e
                ON s.id_emprendimiento = e.id_emprendimiento

            CROSS JOIN LATERAL generate_series(
                $1::DATE + h.hora_inicio,
                $1::DATE + h.hora_fin
                    - s.duracion_min * INTERVAL '1 minute',
                s.duracion_min * INTERVAL '1 minute'
            ) AS horas(hora)

            WHERE t.id_trabajadora = $3
              AND s.id_servicio = $4
              AND h.dia_semana = $2
              AND horas.hora = $1::DATE + $5::TIME
              AND EXISTS (
                  SELECT 1 FROM suscripcion plan
                  WHERE plan.id_emprendedora=e.id_emprendedora
                    AND plan.acceso_hasta>(CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago')::date
              )
              AND t.id_emprendimiento = e.id_emprendimiento
              AND t.activa = TRUE
              AND h.activo = TRUE
              AND s.activo = TRUE
              AND e.estado = TRUE

              -- Rechazamos horas bloqueadas.
              AND NOT EXISTS (
                  SELECT 1
                  FROM bloqueo_horario b
                  WHERE b.id_trabajadora = t.id_trabajadora
                    AND horas.hora < b.fecha_fin
                    AND horas.hora
                        + s.duracion_min * INTERVAL '1 minute'
                        > b.fecha_inicio
              )

              -- Rechazamos horas ocupadas por otras reservas.
              AND NOT EXISTS (
                  SELECT 1
                  FROM reserva r
                  WHERE r.id_trabajadora = t.id_trabajadora
                    AND r.estado IN (
                        'pendiente_abono',
                        'confirmada'
                    )
                    AND horas.hora < r.fecha_hora_fin
                    AND horas.hora
                        + s.duracion_min * INTERVAL '1 minute'
                        > r.fecha_hora_inicio
              )

            LIMIT 1;
        `, [
            fecha,
            diaSemana,
            idTrabajadora,
            idServicio,
            hora
        ]);

        // Si no encontramos el horario, no creamos la reserva.
        if (disponibilidad.rows.length === 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "El horario no está disponible"
            });
        }

        // Obtenemos la información verificada del servicio.
        const datos = disponibilidad.rows[0];
        if(!abonoCLPValido(Number(datos.monto_abono),Number(datos.precio))){
            await clienteDB.query('ROLLBACK');
            return res.status(409).json({mensaje:'El abono del servicio requiere corrección antes de reservar.'});
        }

        // Registramos la reserva como pendiente de abono.
       
        // Generamos un token seguro y único para consultar la reserva.
        const { randomUUID } = require("node:crypto");
        const tokenConsulta = randomUUID();

        // Registramos la reserva junto con su token de consulta.
        const nuevaReserva = await clienteDB.query(`
            INSERT INTO reserva (
                id_emprendimiento,
                id_servicio,
                id_trabajadora,
                id_clienta,
                fecha_hora_inicio,
                fecha_hora_fin,
                estado,
                precio_servicio,
                monto_abono,
                token_consulta,
                nombre_clienta
            )
            VALUES (
                $1, $2, $3, $4, $5, $6,
                'pendiente_abono', $7, $8, $9, $10
            )
            RETURNING
                id_reserva,
                id_servicio,
                id_trabajadora,
                id_clienta,
                fecha_hora_inicio,
                fecha_hora_fin,
                estado,
                precio_servicio,
                monto_abono,
                token_consulta;
        `, [
            datos.id_emprendimiento,
            idServicio,
            idTrabajadora,
            idClienta,
            datos.fecha_hora_inicio,
            datos.fecha_hora_fin,
            datos.precio,
            datos.monto_abono,
            tokenConsulta,
            nombreReserva?.trim() || null
        ]);


        // Confirmamos los cambios en PostgreSQL.
        await clienteDB.query("COMMIT");

        // Informamos que la reserva fue registrada.
        return res.status(201).json({
            mensaje: "Reserva registrada correctamente",
            reserva: nuevaReserva.rows[0]
        });

    } catch (error) {

        // Revertimos los cambios si ocurre un error.
        if (clienteDB) {
            try {
                await clienteDB.query("ROLLBACK");
            } catch (errorRollback) {
                console.error(
                    "Error al revertir reserva:",
                    errorRollback.message
                );
            }
        }

        console.error("Error al crear reserva:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar la reserva"
        });

    } finally {

        // Liberamos la conexión para que pueda reutilizarse.
        if (clienteDB) {
            clienteDB.release();
        }
    }
});





/**
 * MERAKI - Consultar una reserva mediante su token privado.
 *
 * No requiere iniciar sesión.
 * Solo devuelve información necesaria sobre la reserva.
 */
app.get("/api/reservas/consulta/:token", async (req, res) => {
    try {
        const token = req.params.token;

        // Comprobamos que el token tenga el formato de un UUID.
        const formatoUUID =
            /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

        if (!formatoUUID.test(token)) {
            return res.status(400).json({
                mensaje: "El enlace de consulta no es válido"
            });
        }

        // Buscamos la reserva mediante su token privado.
        const resultado = await pool.query(`
            SELECT
                r.id_reserva,
                pagos.*,
                r.monto_abono,
                r.estado,
                r.fecha_hora_inicio,
                r.fecha_hora_fin,
                TO_CHAR(r.fecha_hora_inicio, 'YYYY-MM-DD"T"HH24:MI:SS') AS fecha_hora_inicio_civil,
                TO_CHAR(r.fecha_hora_fin, 'YYYY-MM-DD"T"HH24:MI:SS') AS fecha_hora_fin_civil,
                'America/Santiago'::text AS zona_horaria,
                s.nombre AS servicio,
                e.nombre AS emprendimiento
            FROM reserva r
            INNER JOIN servicio s
                ON r.id_servicio = s.id_servicio
            INNER JOIN emprendimiento e
                ON r.id_emprendimiento = e.id_emprendimiento
            CROSS JOIN LATERAL (
                SELECT count(*) > 0 AS tiene_abonos,
                       COALESCE(bool_or(a.estado = 'aprobado'), false) AS aprobado,
                       COALESCE(bool_or(a.estado = 'pendiente'), false) AS pendiente,
                       COALESCE(bool_and((
                           a.estado = 'rechazado' AND a.estado_proceso_webpay = 'resuelto'
                           AND a.token_transaccion ~ '^[a-zA-Z0-9]{64}$'
                           AND btrim(a.buy_order) <> ''
                           AND a.monto > 0 AND trunc(a.monto) = a.monto
                       ) IS TRUE), false) AS rechazos_concluyentes
                FROM abono a WHERE a.id_reserva = r.id_reserva
            ) pagos
            WHERE r.token_consulta = $1;
        `, [token]);

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensaje: "No se encontró la reserva"
            });
        }

        // No devolvemos datos personales ni el token privado.
        const {tiene_abonos, aprobado, pendiente, rechazos_concluyentes, monto_abono, ...reservaPublica} = resultado.rows[0];
        const detalleGestion=await gestionesReserva.leer(pool,reservaPublica.id_reserva);
        reservaPublica.asistencia_confirmada_en=detalleGestion.asistencia_confirmada_en;
        const monto = Number(monto_abono);
        let pago;
        if (aprobado || reservaPublica.estado === 'confirmada') {
            pago = {estado:'confirmado',puede_iniciar:false,motivo:'reserva_o_abono_confirmado'};
        } else if (reservaPublica.estado !== 'pendiente_abono') {
            pago = {estado:'no_disponible',puede_iniciar:false,motivo:'estado_reserva'};
        } else if (pendiente || (tiene_abonos && !rechazos_concluyentes)) {
            pago = {estado:'en_revision',puede_iniciar:false,motivo:'intento_bloqueante'};
        } else if (!Number.isSafeInteger(monto) || monto <= 0 || !urlRetornoVisual(process.env.WEBPAY_RETURN_URL)) {
            pago = {estado:'no_disponible',puede_iniciar:false,motivo:'pago_no_disponible'};
        } else {
            pago = {estado:rechazos_concluyentes?'rechazado':'disponible',puede_iniciar:true,motivo:null};
        }
        return res.status(200).json({
            mensaje: "Reserva encontrada",
            reserva: reservaPublica,
            pago,
            solicitud_cancelacion:detalleGestion.solicitud,
            capacidades: {
                confirmar_asistencia: detalleGestion.futura && reservaPublica.estado==='confirmada' && aprobado && !detalleGestion.asistencia_confirmada_en && detalleGestion.solicitud?.estado!=='pendiente',
                solicitar_cancelacion: detalleGestion.futura && ['confirmada','pendiente_abono'].includes(reservaPublica.estado) && tiene_abonos && !detalleGestion.solicitud,
                cancelar: !tiene_abonos && ["pendiente_abono", "confirmada"].includes(reservaPublica.estado),
                motivoCancelacion: tiene_abonos
                    ? "Esta reserva tiene un pago asociado. Contacta al emprendimiento para gestionar la cancelación."
                    : null
            }
        });

    } catch (error) {
        console.error(
            "Error al consultar reserva:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudo consultar la reserva"
        });
    }
});



/**
 * MERAKI - Cancelar una reserva mediante su token privado.
 *
 * No requiere iniciar sesión.
 * Solo permite cancelar reservas sin intentos de pago
 * registrados, para evitar conflictos con Webpay.
 */
app.patch("/api/reservas/consulta/:token/cancelar", async (req, res) => {
    let clienteDB;

    try {
        const token = req.params.token;

        // Validamos el formato del token privado.
        const formatoUUID =
            /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

        if (!formatoUUID.test(token)) {
            return res.status(400).json({
                mensaje: "El enlace de cancelación no es válido"
            });
        }

        // Usamos una transacción para proteger la operación.
        clienteDB = await pool.connect();
        await clienteDB.query("BEGIN");

        // Bloqueamos la reserva mientras comprobamos su estado.
        const resultado = await clienteDB.query(`
            SELECT id_reserva, estado
            FROM reserva
            WHERE token_consulta = $1
            FOR UPDATE;
        `, [token]);

        if (resultado.rows.length === 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(404).json({
                mensaje: "No se encontró la reserva"
            });
        }

        const reserva = resultado.rows[0];

        // Solo permitimos cancelar reservas pendientes o confirmadas.
        if (!["pendiente_abono", "confirmada"].includes(reserva.estado)) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "La reserva no puede cancelarse en su estado actual"
            });
        }

        // Comprobamos si existe algún intento de pago.
        // Por seguridad, impedimos cancelar aunque el abono
        // esté pendiente o rechazado.
        const abonos = await clienteDB.query(`
            SELECT 1
            FROM abono
            WHERE id_reserva = $1
            LIMIT 1;
        `, [reserva.id_reserva]);

        if (abonos.rows.length > 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "La reserva tiene un pago asociado. Contacta al emprendimiento para gestionar la cancelación."
            });
        }

        // Cancelamos únicamente si sigue en un estado permitido.
        const cancelacion = await clienteDB.query(`
            UPDATE reserva
            SET estado = 'cancelada'
            WHERE id_reserva = $1
              AND estado IN ('pendiente_abono', 'confirmada')
            RETURNING id_reserva, estado;
        `, [reserva.id_reserva]);

        await clienteDB.query("COMMIT");

        return res.status(200).json({
            mensaje: "Reserva cancelada correctamente",
            reserva: cancelacion.rows[0]
        });

    } catch (error) {
        if (clienteDB) {
            try {
                await clienteDB.query("ROLLBACK");
            } catch (errorRollback) {
                console.error("Error al revertir cancelación:", errorRollback.message);
            }
        }

        console.error("Error al cancelar reserva por token:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo cancelar la reserva"
        });

    } finally {
        if (clienteDB) {
            clienteDB.release();
        }
    }
});







// ============================================================
// WEBPAY PLUS — INICIAR PAGO DE ABONO
// ============================================================


const iniciarAbonoWebpay = require('./inicio-webpay').crearInicioWebpay({pool, webpay});

app.post('/api/abonos/iniciar', verificarSesion, async (req, res) => {
    const idReserva = Number(req.body?.id_reserva);
    if (!Number.isSafeInteger(idReserva) || idReserva <= 0) {
        return res.status(400).json({mensaje: 'Debes indicar una reserva válida'});
    }
    const resultado = await iniciarAbonoWebpay(
        {idReserva, propietaria: req.session.idEmprendedora}, process.env.WEBPAY_RETURN_URL);
    return res.status(resultado.codigo).json(resultado.cuerpo);
});

app.post('/api/abonos/cliente/iniciar', async (req, res) => {
    const token = req.body?.token_consulta;
    const formatoUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (typeof token !== 'string' || !formatoUUID.test(token)) {
        return res.status(400).json({mensaje: 'El token de la reserva no es válido'});
    }
    res.set('Cache-Control','no-store');
    res.set('Referrer-Policy','no-referrer');
    const retorno = urlRetornoVisual(process.env.WEBPAY_RETURN_URL,req.protocol+'://'+req.get('host'));
    if(!retorno)return res.status(502).json({mensaje:'El pago no está disponible por ahora.'});
    const resultado = await iniciarAbonoWebpay({token}, retorno);
    if(resultado.codigo===201)resultado.cuerpo.correlacion=referenciasWebpay.correlacion(resultado.cuerpo.token);
    return res.status(resultado.codigo).json(resultado.cuerpo);
});

// ============================================================
// WEBPAY PLUS — RETORNO Y VERIFICACIÓN DEL ABONO
// ============================================================

montarProcesamientoWebpay(app, {
    pool, webpay, verificarSesion, referencias:referenciasWebpay,
    registrar: registrarNotificacionConfirmacion, notificar: notificarReservaConfirmada
});

// Reservas de emprendimientos autenticados.
app.get("/api/reservas", verificarSesion, async (req, res) => {
    try {
        // Recibimos el identificador del emprendimiento.
        const idEmprendimiento = Number(req.query.id_emprendimiento);

        // Validamos que sea un identificador correcto.
        if (
            !Number.isSafeInteger(idEmprendimiento) ||
            idEmprendimiento <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar un emprendimiento válido"
            });
        }
// Verificamos que el emprendimiento pertenezca a la emprendedora conectada.
const propiedad = await pool.query(`
    SELECT id_emprendimiento
    FROM emprendimiento
    WHERE id_emprendimiento = $1
      AND id_emprendedora = $2;
`, [idEmprendimiento, req.session.idEmprendedora]);

// Si no pertenece a su cuenta, rechazamos la consulta.
if (propiedad.rows.length === 0) {
    return res.status(403).json({
        mensaje: "No tienes permiso para consultar este emprendimiento"
    });
}
        // Consultamos las reservas y sus datos relacionados.
        const resultado = await pool.query(`
            SELECT
                r.id_reserva,
                r.id_servicio,
                r.id_trabajadora,
                COALESCE(r.nombre_clienta,c.nombre) AS clienta,
                t.nombre AS trabajadora,
                s.nombre AS servicio,
               TO_CHAR(r.fecha_hora_inicio, 'YYYY-MM-DD"T"HH24:MI:SS') AS fecha_hora_inicio,
               TO_CHAR(r.fecha_hora_fin, 'YYYY-MM-DD"T"HH24:MI:SS') AS fecha_hora_fin,
                r.estado,
                r.precio_servicio,
                r.monto_abono,
                r.asistencia_confirmada_en,
                (SELECT estado FROM solicitud_cancelacion sc WHERE sc.id_reserva=r.id_reserva) AS estado_solicitud_cancelacion,
                ultimo.id_abono,
                ultimo.estado AS estado_abono,
                (ultimo.id_abono IS NULL AND r.estado IN ('pendiente_abono','confirmada')) AS puede_cancelar,
                (r.estado='confirmada' AND r.fecha_hora_fin<=CURRENT_TIMESTAMP) AS puede_cerrar
            FROM reserva r
            LEFT JOIN clienta c
                ON r.id_clienta = c.id_clienta
            INNER JOIN trabajadora t
                ON r.id_trabajadora = t.id_trabajadora
           INNER JOIN servicio s
                ON r.id_servicio = s.id_servicio

           -- Relacionamos la reserva con su emprendimiento.
           INNER JOIN emprendimiento e
                ON r.id_emprendimiento = e.id_emprendimiento

           LEFT JOIN LATERAL (
               SELECT a.id_abono,a.estado FROM abono a
               WHERE a.id_reserva=r.id_reserva ORDER BY a.id_abono DESC LIMIT 1
           ) ultimo ON TRUE

           -- Verificamos el emprendimiento y su propietaria.
           WHERE r.id_emprendimiento = $1
            AND e.id_emprendedora = $2

           ORDER BY r.fecha_hora_inicio;
        `, [idEmprendimiento, req.session.idEmprendedora]);

        // Enviamos las reservas al navegador.
        res.json(resultado.rows);

    } catch (error) {
        console.error("Error al consultar reservas:", error.message);

        res.status(500).json({
            mensaje: "Error al obtener las reservas"
        });
    }
});




// Ruta para cancelar una reserva.
// Es provisional para desarrollo local: requiere autenticación
// y autorización antes de publicar el sistema.
// Solo las emprendedoras autenticadas pueden solicitar cancelaciones.
app.patch("/api/reservas/:id/cancelar", verificarSesion, async (req, res) => {
    const idReserva = Number(req.params.id);

    if (!Number.isSafeInteger(idReserva) || idReserva <= 0) {
        return res.status(400).json({
            mensaje: "El identificador de la reserva no es válido"
        });
    }

    let clienteDB;

    try {
        clienteDB = await pool.connect();
        await clienteDB.query("BEGIN");

        // Comprobar que la reserva pertenece a la emprendedora.
        // Bloquear la fila para impedir modificaciones simultáneas.
        const consulta = await clienteDB.query(`
            SELECT r.id_reserva, r.estado
            FROM reserva r
            INNER JOIN emprendimiento e
                ON r.id_emprendimiento = e.id_emprendimiento
            WHERE r.id_reserva = $1
              AND e.id_emprendedora = $2
            FOR UPDATE OF r;
        `, [idReserva, req.session.idEmprendedora]);

        if (consulta.rows.length === 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(404).json({
                mensaje: "La reserva no existe"
            });
        }

        // Solo se permiten estados pendientes o confirmados.
        if (!["pendiente_abono", "confirmada"].includes(consulta.rows[0].estado)) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "La reserva no puede cancelarse en su estado actual"
            });
        }

        // Revisar los abonos después de bloquear la reserva.
        const abonos = await clienteDB.query(`
            SELECT 1
            FROM abono
            WHERE id_reserva = $1
            LIMIT 1;
        `, [idReserva]);

        if (abonos.rows.length > 0) {
            await clienteDB.query("ROLLBACK");

            return res.status(409).json({
                mensaje: "La reserva tiene un pago asociado. Debes gestionar el abono antes de cancelarla."
            });
        }

        // Actualizar el estado mientras seguimos en la transacción.
        const resultado = await clienteDB.query(`
            UPDATE reserva
            SET estado = 'cancelada'
            WHERE id_reserva = $1
              AND estado IN ('pendiente_abono', 'confirmada')
            RETURNING
                id_reserva,
                id_clienta,
                id_trabajadora,
                id_servicio,
                estado,
                TO_CHAR(
                    fecha_hora_inicio,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS fecha_hora_inicio;
        `, [idReserva]);

        if (resultado.rowCount !== 1) {
            throw new Error("No se pudo actualizar la reserva");
        }

        await clienteDB.query("COMMIT");

        return res.status(200).json({
            mensaje: "Reserva cancelada correctamente",
            reserva: resultado.rows[0]
        });

    } catch (error) {
        if (clienteDB) {
            try {
                await clienteDB.query("ROLLBACK");
            } catch (errorRollback) {
                console.error(
                    "Error al revertir cancelación:",
                    errorRollback.message
                );
            }
        }

        console.error("Error al cancelar reserva:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo cancelar la reserva"
        });

    } finally {
        if (clienteDB) {
            clienteDB.release();
        }
    }
});







// ============================================================
// CONFIRMAR RESERVAS DEL BACK OFFICE
// ============================================================

app.patch("/api/reservas/:id/confirmar", verificarSesion, async (req, res) => {
    try {
        // Obtenemos el identificador de la reserva.
        const idReserva = Number(req.params.id);

        // Validamos que sea un entero positivo.
        if (!Number.isSafeInteger(idReserva) || idReserva <= 0) {
            return res.status(400).json({
                mensaje: "El identificador de la reserva no es válido"
            });
        }

        // Confirmamos solo reservas pendientes de abono
        // que pertenezcan a los emprendimientos de la sesión.
        const resultado = await pool.query(`
            UPDATE reserva
            SET estado = 'confirmada'
            WHERE id_reserva = $1
              AND estado = 'pendiente_abono'

            -- Exigir un abono aprobado antes de confirmar.
              AND EXISTS (
              SELECT 1
              FROM abono a
              WHERE a.id_reserva = reserva.id_reserva
              AND a.estado = 'aprobado'
              AND a.monto = reserva.monto_abono
              AND a.fecha_pago IS NOT NULL
               )

              AND id_emprendimiento IN (
                  SELECT id_emprendimiento
                  FROM emprendimiento
                  WHERE id_emprendedora = $2
              )
            RETURNING
                id_reserva,
                id_clienta,
                id_trabajadora,
                id_servicio,
                estado,
                TO_CHAR(
                    fecha_hora_inicio,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS fecha_hora_inicio;
        `, [
            idReserva,
            req.session.idEmprendedora
        ]);

        // Si no se actualizó, verificamos si la reserva existe.
        if (resultado.rows.length === 0) {
            const existente = await pool.query(`
                SELECT r.estado
                FROM reserva r
                INNER JOIN emprendimiento e
                    ON r.id_emprendimiento = e.id_emprendimiento
                WHERE r.id_reserva = $1
                  AND e.id_emprendedora = $2;
            `, [
                idReserva,
                req.session.idEmprendedora
            ]);

            if (existente.rows.length === 0) {
                return res.status(404).json({
                    mensaje: "La reserva no existe"
                });
            }

            return res.status(409).json({
                mensaje: "La reserva no puede confirmarse en su estado actual"
            });
        }

        // Respondemos con la reserva confirmada.
        return res.status(200).json({
            mensaje: "Reserva confirmada correctamente",
            reserva: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al confirmar reserva:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo confirmar la reserva"
        });
    }
});



// Marcar una reserva como atendida
app.patch("/api/reservas/:id/atender", verificarSesion, async (req, res) => {
    try {
        const idReserva = Number(req.params.id);
        const idEmprendedora = req.session.idEmprendedora;

        if (!Number.isInteger(idReserva) || idReserva <= 0) {
            return res.status(400).json({
                mensaje: "ID de reserva inválido"
            });
        }

        const resultado = await pool.query(
            `
            UPDATE reserva AS r
            SET estado = 'atendida'
            FROM emprendimiento AS e
            WHERE r.id_reserva = $1
              AND r.id_emprendimiento = e.id_emprendimiento
              AND e.id_emprendedora = $2
              AND r.estado = 'confirmada'
              AND r.fecha_hora_fin <= CURRENT_TIMESTAMP
            RETURNING r.id_reserva, r.estado
            `,
            [idReserva, idEmprendedora]
        );

        if (resultado.rowCount === 0) {
            return res.status(404).json({
                mensaje: "Reserva no encontrada o no disponible para marcar como atendida"
            });
        }

        return res.json({
            mensaje: "Reserva marcada como atendida correctamente",
            reserva: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al marcar reserva como atendida:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo actualizar la reserva"
        });
    }
});


// Marcar una reserva como no atendida.
app.patch("/api/reservas/:id/no-atendida", verificarSesion, async (req, res) => {
    try {
        const idReserva = Number(req.params.id);
        const idEmprendedora = req.session.idEmprendedora;

        if (!Number.isSafeInteger(idReserva) || idReserva <= 0) {
            return res.status(400).json({
                mensaje: "El identificador de la reserva no es válido"
            });
        }

        const resultado = await pool.query(`
            UPDATE reserva AS r
            SET estado = 'no_atendida'
            FROM emprendimiento AS e
            WHERE r.id_reserva = $1
              AND r.id_emprendimiento = e.id_emprendimiento
              AND e.id_emprendedora = $2
              AND r.estado = 'confirmada'
              AND r.fecha_hora_fin <= CURRENT_TIMESTAMP
            RETURNING r.id_reserva, r.estado;
        `, [idReserva, idEmprendedora]);

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensaje: "Reserva no encontrada o no disponible para marcar como no atendida"
            });
        }

        return res.json({
            mensaje: "Reserva marcada como no atendida correctamente",
            reserva: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al marcar reserva como no atendida:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo actualizar la reserva"
        });
    }
});





montarIncorporacion(app,pool,verificarSesion);
montarFotos(app,{pool,verificarSesion});

// Ruta para registrar nuevas emprendedoras en Meraki.
app.post("/api/auth/registro", async (req, res) => {
    try {
        if(!req.body||typeof req.body!=='object'||Array.isArray(req.body)||Object.keys(req.body).some(k=>!['nombre','apellido','rut','correo','password','telefono'].includes(k))){return res.status(400).json({mensaje:'Datos de registro inválidos'});}
        if(req.get('Sec-Fetch-Site')==='cross-site'||(req.get('Origin')&&req.get('Origin')!==req.protocol+'://'+req.get('Host')))return res.status(403).json({mensaje:'Solicitud no autorizada'});
        // Recibimos los datos enviados desde el formulario.
        const {
            nombre,
            apellido,
            rut,
            correo,
            password,
            telefono
        } = req.body || {};

        // Comprobamos que los datos obligatorios sean textos válidos.
        if (
            [nombre, apellido, rut, correo, password].some(
                dato => typeof dato !== "string" || dato.trim() === ""
            )
        ) {
            return res.status(400).json({
                mensaje: "Debes completar todos los campos obligatorios"
            });
        }

        // Comprobamos que los campos no superen límites razonables.
        if (
            nombre.length > 100 ||
            apellido.length > 100 ||
            rut.length > 20 ||
            correo.length > 150 ||
            (telefono != null &&
                (typeof telefono !== "string" || telefono.length > 20))
        ) {
            return res.status(400).json({
                mensaje: "Uno o más campos superan el tamaño permitido"
            });
        }

        // Normalizamos los datos para evitar diferencias innecesarias.
        const nombreLimpio = nombre.trim();
        const apellidoLimpio = apellido.trim();
        const rutLimpio = rut.trim().toUpperCase().replaceAll('.','');
        const correoLimpio = correo.trim().toLowerCase();
        const telefonoLimpio = telefono?.trim() || null;

        // Validamos un formato básico de correo electrónico.
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correoLimpio)) {
            return res.status(400).json({
                mensaje: "El correo electrónico no tiene un formato válido"
            });
        }

        // Exigimos una contraseña de al menos 12 caracteres.
        // bcrypt trabaja con un máximo de 72 bytes de contraseña.
        if (
            password.length < 12 ||
            Buffer.byteLength(password, "utf8") > 72
        ) {
            return res.status(400).json({
                mensaje: "La contraseña debe tener al menos 12 caracteres y no superar 72 bytes"
            });
        }

        // Validación básica del formato del RUT.
        // Más adelante agregaremos la comprobación del dígito verificador.
        if (!/^\d{1,8}-[0-9K]$/.test(rutLimpio)) {
            return res.status(400).json({
                mensaje: "El RUT contiene caracteres no permitidos"
            });
        }

        // Generamos el hash. Nunca guardamos la contraseña original.
        const passwordHash = await bcrypt.hash(password, 12);

        // Registramos la emprendedora en PostgreSQL.
        const resultado = await crearCuenta(pool,[nombreLimpio,apellidoLimpio,rutLimpio,correoLimpio,passwordHash,telefonoLimpio]);

        // Respondemos sin mostrar la contraseña ni su hash.
        return res.status(201).json({
            mensaje: "Emprendedora registrada correctamente",
            emprendedora: resultado.rows[0]
        });

    } catch (error) {

        // PostgreSQL utiliza 23505 para valores UNIQUE duplicados.
        if (error.code === "23505") {
            return res.status(409).json({
                mensaje: "El correo o RUT ya está registrado"
            });
        }

        console.error("Error al registrar emprendedora:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo registrar la emprendedora"
        });
    }
});
// Ruta para comprobar las credenciales de una emprendedora.
app.post("/api/auth/login", async (req, res) => {
    // Mensaje temporal para comprobar que esta ruta recibe solicitudes.
console.log("MERAKI: solicitud de login recibida");
    try {
        // Recibimos el correo y la contraseña.
        const { correo, password } = req.body || {};

        // Validamos los datos recibidos.
        if (
            typeof correo !== "string" ||
            typeof password !== "string" ||
            correo.trim() === "" ||
            password === ""
        ) {
            return res.status(400).json({
                mensaje: "Debes ingresar correo y contraseña"
            });
        }

        // Normalizamos el correo electrónico.
        const correoLimpio = correo.trim().toLowerCase();

        // Buscamos la cuenta y su contraseña protegida.
        const resultado = await pool.query(`
            SELECT
                id_emprendedora,
                nombre,
                apellido,
                correo,
                password_hash,
                estado
            FROM emprendedora
            WHERE correo = $1;
        `, [correoLimpio]);

        // Si el correo no existe, rechazamos el acceso.
        if (resultado.rows.length === 0) {
            return res.status(401).json({
                mensaje: "Correo o contraseña incorrectos"
            });
        }

        const emprendedora = resultado.rows[0];

        // Comparamos la contraseña recibida con el hash.
        const passwordCorrecta = await bcrypt.compare(
            password,
            emprendedora.password_hash
        );

        if (!passwordCorrecta) {
            return res.status(401).json({
                mensaje: "Correo o contraseña incorrectos"
            });
        }

        // Comprobamos que la cuenta esté activa.
        if (emprendedora.estado !== "activa") {
            return res.status(403).json({
                mensaje: "La cuenta no está activa"
            });
        }

        // Creamos una nueva sesión después de verificar las credenciales.
await new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
        if (error) reject(error);
        else resolve();
    });
});

// Guardamos el identificador de la emprendedora conectada.
req.session.idEmprendedora = emprendedora.id_emprendedora;

// Guardamos la sesión en PostgreSQL.
await new Promise((resolve, reject) => {
    req.session.save((error) => {
        if (error) reject(error);
        else resolve();
    });
});
        // Respondemos sin incluir la contraseña ni su hash.
        return res.json({
            mensaje: "Credenciales verificadas correctamente",
            emprendedora: {
                id_emprendedora: emprendedora.id_emprendedora,
                nombre: emprendedora.nombre,
                apellido: emprendedora.apellido,
                correo: emprendedora.correo
            }
        });

    } catch (error) {
        console.error("Error al verificar credenciales:", error.message);

        return res.status(500).json({
            mensaje: "Error al verificar las credenciales"
        });
    }
});
// Ruta para consultar la emprendedora que inició sesión.
app.get("/api/auth/yo", async (req, res) => {
    try {
        // Comprobamos si existe una sesión autenticada.
        if (!req.session.idEmprendedora) {
            return res.status(401).json({
                mensaje: "Debes iniciar sesión"
            });
        }

        // Consultamos los datos actuales de la emprendedora.
        const resultado = await pool.query(`
            SELECT
                id_emprendedora,
                nombre,
                apellido,
                correo
            FROM emprendedora
            WHERE id_emprendedora = $1
              AND estado = 'activa';
        `, [req.session.idEmprendedora]);

        // Rechazamos el acceso si la cuenta ya no está activa.
        if (resultado.rows.length === 0) {
            return res.status(401).json({
                mensaje: "La sesión ya no corresponde a una cuenta activa"
            });
        }

        // Devolvemos los datos sin incluir contraseñas.
        return res.json({
            mensaje: "Sesión activa",
            emprendedora: resultado.rows[0]
        });

    } catch (error) {
        console.error("Error al consultar sesión:", error.message);

        return res.status(500).json({
            mensaje: "Error al consultar la sesión"
        });
    }
});
// Ruta para cerrar la sesión de una emprendedora.
app.post("/api/auth/logout", async (req, res) => {
    try {
        // Comprobamos que exista una sesión autenticada.
        if (!req.session.idEmprendedora) {
            return res.status(401).json({
                mensaje: "Debes iniciar sesión"
            });
        }

        // Eliminamos la sesión almacenada en PostgreSQL.
        await new Promise((resolve, reject) => {
            req.session.destroy((error) => {
                if (error) reject(error);
                else resolve();
            });
        });

        // Eliminamos la cookie del navegador.
        res.clearCookie("meraki.sid", {
            path: "/",
            httpOnly: true,
            sameSite: "lax",
            secure: false
        });

        // Confirmamos el cierre de sesión.
        return res.json({
            mensaje: "Sesión cerrada correctamente"
        });

    } catch (error) {
        console.error("Error al cerrar sesión:", error.message);

        return res.status(500).json({
            mensaje: "No se pudo cerrar la sesión"
        });
    }
});





/* ============================================================
   CONSULTAR MIS EMPRENDIMIENTOS - BACK OFFICE
   ============================================================ */

// Esta ruta permite que una emprendedora consulte los negocios
// asociados a su cuenta, incluyendo sus datos de ubicación.
app.get("/api/mis-emprendimientos", verificarSesion, async (req, res) => {
    try {
        // Obtenemos el identificador desde la sesión iniciada.
        const idEmprendedora = req.session.idEmprendedora;

        // Consultamos solamente los emprendimientos de la cuenta.
        // $1 evita incorporar directamente datos a la consulta SQL.
        const resultado = await pool.query(`
            SELECT
                id_emprendimiento,
                nombre,
                descripcion,
                direccion,
                comuna,
                latitud,
                longitud,
                telefono,
                estado
            FROM emprendimiento
            WHERE id_emprendedora = $1
            ORDER BY id_emprendimiento;
        `, [idEmprendedora]);

        // Respondemos con los emprendimientos encontrados.
        return res.status(200).json(resultado.rows);

    } catch (error) {
        // Registramos el problema sin mostrar información interna.
        console.error(
            "Error al consultar mis emprendimientos:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudieron consultar los emprendimientos"
        });
    }
});



/* ============================================================
   EDITAR PERFIL DEL EMPRENDIMIENTO - BACK OFFICE
   ============================================================ */

app.patch("/api/emprendimientos/:id", verificarSesion, async (req, res) => {
    try {
        // Identificamos el emprendimiento que se desea editar.
        const idEmprendimiento = Number(req.params.id);

        if (!Number.isSafeInteger(idEmprendimiento) || idEmprendimiento <= 0) {
            return res.status(400).json({
                mensaje: "Debes indicar un emprendimiento válido"
            });
        }

        let datos;
        try{datos=normalizarNegocio(req.body);}catch(e){return res.status(400).json({mensaje:e.message});}
        const campos=Object.keys(datos);
        const ubicacion={latitud:datos.latitud,longitud:datos.longitud};

        // Construimos solamente los campos enviados.
        // Los valores se envían mediante parámetros SQL.
        const asignaciones = [];
        const valores = [];

        for (const campo of campos) {
            valores.push(
                campo === "latitud" || campo === "longitud" ? ubicacion[campo] :
                datos[campo] === null ? null : datos[campo].trim()
            );

            asignaciones.push(`${campo} = $${valores.length}`);
        }

        // El último parámetro identifica el emprendimiento.
        valores.push(idEmprendimiento);
        const posicionId = valores.length;

        // La sesión determina quién puede realizar la modificación.
        valores.push(req.session.idEmprendedora);
        const posicionPropietaria = valores.length;

        const resultado = await pool.query(`
            UPDATE emprendimiento
            SET ${asignaciones.join(", ")}
            WHERE id_emprendimiento = $${posicionId}
              AND id_emprendedora = $${posicionPropietaria}
            RETURNING
                id_emprendimiento,
                nombre,
                descripcion,
                direccion,
                comuna,
                latitud,
                longitud,
                telefono,
                estado;
        `, valores);

        // No permitimos editar emprendimientos ajenos.
        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El emprendimiento no existe"
            });
        }

        return res.status(200).json({
            mensaje: "Perfil del emprendimiento actualizado correctamente",
            emprendimiento: resultado.rows[0]
        });

    } catch (error) {
        console.error(
            "Error al editar emprendimiento:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudo actualizar el emprendimiento"
        });
    }
});



// Ruta pública para mostrar los emprendimientos disponibles.
// Las clientas no necesitan iniciar sesión.

/* ============================================================
   CONSULTAR Y BUSCAR EMPRENDIMIENTOS - FRONT OFFICE
   ============================================================ */

// Ruta pública para mostrar y buscar emprendimientos activos.
app.get("/api/emprendimientos", async (req, res) => {
    try {
        // Recibimos los filtros opcionales de la URL.
        const { nombre, comuna, id_categoria } = req.query;

        const categoria = typeof id_categoria === "string" ? Number(id_categoria) : null;
        if (id_categoria !== undefined && (
            typeof id_categoria !== "string" || !/^\d+$/.test(id_categoria) ||
            !Number.isSafeInteger(categoria) || categoria < 1 || categoria > 2147483647
        )) {
            return res.status(400).json({ mensaje: "Indica una categoría válida" });
        }

        // Validamos que los filtros sean textos.
        if (
            (nombre !== undefined && typeof nombre !== "string") ||
            (comuna !== undefined && typeof comuna !== "string")
        ) {
            return res.status(400).json({
                mensaje: "Los filtros deben ser textos válidos"
            });
        }

        // Evitamos búsquedas excesivamente largas.
        if (
            (nombre && nombre.length > 150) ||
            (comuna && comuna.length > 100)
        ) {
            return res.status(400).json({
                mensaje: "Los filtros superan el tamaño permitido"
            });
        }

        // Si no se envían filtros, utilizamos textos vacíos.
        const nombreBuscado = nombre?.trim() || "";
        const comunaBuscada = comuna?.trim() || "";

        // Consultamos solamente emprendimientos activos.
        // ILIKE permite buscar sin distinguir mayúsculas y minúsculas.
        const resultado = await pool.query(`
            SELECT
                e.id_emprendimiento,
                nombre,
                descripcion,
                comuna,
                direccion,
                latitud,
                longitud
            FROM emprendimiento e
            WHERE estado = TRUE
              AND nombre ILIKE '%' || $1 || '%'
              AND COALESCE(comuna, '') ILIKE '%' || $2 || '%'
              AND ($3::integer IS NULL OR EXISTS (
                  SELECT 1 FROM servicio s
                  WHERE s.id_emprendimiento = e.id_emprendimiento
                    AND s.id_categoria = $3
                    AND s.activo = TRUE
              ))
            ORDER BY nombre;
        `, [nombreBuscado, comunaBuscada, categoria]);

        // Respondemos con los resultados encontrados.
        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error(
            "Error al buscar emprendimientos:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudieron consultar los emprendimientos"
        });
    }
});


/* ============================================================
   CONSULTAR TRABAJADORAS - FRONT OFFICE
   ============================================================ */

// Ruta pública para consultar las trabajadoras de un emprendimiento.
app.get("/api/emprendimientos/:id/trabajadoras", async (req, res) => {
    try {
        // Obtenemos el identificador del emprendimiento.
        const idEmprendimiento = Number(req.params.id);

        // Comprobamos que sea un número entero positivo.
        if (
            !Number.isSafeInteger(idEmprendimiento) ||
            idEmprendimiento <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar un emprendimiento válido"
            });
        }

        // Comprobamos que el emprendimiento exista y esté activo.
        const emprendimiento = await pool.query(`
            SELECT id_emprendimiento
            FROM emprendimiento
            WHERE id_emprendimiento = $1
              AND estado = TRUE;
        `, [idEmprendimiento]);

        if (emprendimiento.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El emprendimiento no está disponible"
            });
        }

        // Consultamos solamente las trabajadoras activas.
        // No mostramos información privada de sus cuentas.
        const resultado = await pool.query(`
            SELECT
                id_trabajadora,
                nombre,
                apellido,
                descripcion
            FROM trabajadora
            WHERE id_emprendimiento = $1
              AND activa = TRUE
            ORDER BY nombre, apellido;
        `, [idEmprendimiento]);

        // Enviamos los resultados al Front Office.
        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error(
            "Error al consultar trabajadoras públicas:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudieron consultar las trabajadoras"
        });
    }
});



/* ============================================================
   CONSULTAR SERVICIOS POR EMPRENDIMIENTO - FRONT OFFICE
   ============================================================ */

// Ruta pública para consultar los servicios de un emprendimiento.
app.get("/api/emprendimientos/:id/servicios", async (req, res) => {
    try {
        // Obtenemos el ID del emprendimiento desde la URL.
        const idEmprendimiento = Number(req.params.id);

        // Validamos que sea un identificador entero positivo.
        if (
            !Number.isSafeInteger(idEmprendimiento) ||
            idEmprendimiento <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar un emprendimiento válido"
            });
        }

        // Verificamos que el emprendimiento exista y esté activo.
        const emprendimiento = await pool.query(`
            SELECT id_emprendimiento
            FROM emprendimiento
            WHERE id_emprendimiento = $1
              AND estado = TRUE;
        `, [idEmprendimiento]);

        if (emprendimiento.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El emprendimiento no está disponible"
            });
        }

        // Consultamos únicamente los servicios activos del negocio.
        // Incluimos la categoría, precio, duración y abono.
        const resultado = await pool.query(`
            SELECT
                s.id_servicio,
                s.nombre AS servicio,
                s.descripcion,
                c.nombre AS categoria,
                s.precio,
                s.duracion_min,
                s.monto_abono,
                EXISTS (
                    SELECT 1 FROM trabajadora_servicio ts
                    JOIN trabajadora t ON t.id_trabajadora=ts.id_trabajadora
                    WHERE ts.id_servicio=s.id_servicio AND t.activa=TRUE
                      AND t.id_emprendimiento=s.id_emprendimiento
                ) AND EXISTS (
                    SELECT 1 FROM emprendimiento negocio JOIN suscripcion plan ON plan.id_emprendedora=negocio.id_emprendedora
                    WHERE negocio.id_emprendimiento=s.id_emprendimiento
                      AND plan.acceso_hasta>(CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago')::date
                ) AS reservable,
                (SELECT i.url FROM imagen_servicio i WHERE i.id_servicio=s.id_servicio AND i.url LIKE '/media/servicios/%' ORDER BY i.id_imagen DESC LIMIT 1) AS imagen_url
            FROM servicio s
            INNER JOIN categoria c
                ON s.id_categoria = c.id_categoria
            WHERE s.id_emprendimiento = $1
              AND s.activo = TRUE
            ORDER BY s.nombre;
        `, [idEmprendimiento]);

        // Devolvemos los servicios al Front Office.
        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error(
            "Error al consultar servicios del emprendimiento:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudieron consultar los servicios"
        });
    }
});


/* ============================================================
   CONSULTAR TRABAJADORAS POR SERVICIO - FRONT OFFICE
   ============================================================ */

// Permite consultar quiénes realizan un servicio específico.
app.get("/api/servicios/:id/trabajadoras", async (req, res) => {
    try {
        // Obtenemos el identificador del servicio.
        const idServicio = Number(req.params.id);

        // Validamos que sea un entero positivo.
        if (
            !Number.isSafeInteger(idServicio) ||
            idServicio <= 0
        ) {
            return res.status(400).json({
                mensaje: "Debes indicar un servicio válido"
            });
        }

        // Comprobamos que el servicio y su emprendimiento estén activos.
        const servicio = await pool.query(`
            SELECT s.id_servicio
            FROM servicio s
            INNER JOIN emprendimiento e
                ON s.id_emprendimiento = e.id_emprendimiento
            WHERE s.id_servicio = $1
              AND s.activo = TRUE
              AND e.estado = TRUE;
        `, [idServicio]);

        if (servicio.rows.length === 0) {
            return res.status(404).json({
                mensaje: "El servicio no está disponible"
            });
        }

        // Consultamos las trabajadoras activas asignadas al servicio.
        // Verificamos que pertenezcan al mismo emprendimiento.
        const resultado = await pool.query(`
            SELECT
                t.id_trabajadora,
                t.nombre,
                t.apellido,
                t.descripcion
            FROM trabajadora_servicio ts
            INNER JOIN trabajadora t
                ON ts.id_trabajadora = t.id_trabajadora
            INNER JOIN servicio s
                ON ts.id_servicio = s.id_servicio
            WHERE ts.id_servicio = $1
              AND t.id_emprendimiento = s.id_emprendimiento
              AND t.activa = TRUE
            ORDER BY t.nombre, t.apellido;
        `, [idServicio]);

        // Devolvemos las trabajadoras disponibles para ese servicio.
        return res.status(200).json(resultado.rows);

    } catch (error) {
        console.error(
            "Error al consultar trabajadoras por servicio:",
            error.message
        );

        return res.status(500).json({
            mensaje: "No se pudieron consultar las trabajadoras"
        });
    }
});




















// Iniciamos el servidor en el puerto 3000.
if (require.main === module) app.listen(Number(process.env.PORT || 3000),process.env.MERAKI_PROVEEDORES_EXTERNOS==='0'?'127.0.0.1':undefined, () => {
    console.log(`Servidor de Meraki funcionando en http://localhost:${Number(process.env.PORT || 3000)}`);
    // El servidor revisa vencimientos; no existe un endpoint público para disparar cargos.
    if(process.env.MERAKI_SUSCRIPCIONES_AUTOMATICAS!=='0')iniciarPlanificador(suscripciones);
});
console.log("Iniciando Backend de Meraki");


module.exports=app;
