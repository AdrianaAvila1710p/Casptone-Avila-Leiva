const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm'), fs = require('node:fs'), path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../../frontend/front-office/index.html'), 'utf8');
const script = fs.readFileSync(path.join(__dirname, '../../frontend/front-office/front.js'), 'utf8');
class Elemento {
    constructor(tag = 'div') { this.tag = tag; this.children = []; this.hidden = false; this.disabled = false; this.dataset = {}; this.attributes = {}; this.textContent = ''; }
    set value(v) { this._value = String(v); }
    get value() { return this._value ?? (this.tag === 'select' ? this.children.find(c => !c.disabled)?.value || '' : ''); }
    get selectedOptions() { return this.children.filter(c => c.value === this.value); }
    append(...hijos) {
        for(const hijo of hijos){
            if(hijo.parentElement)hijo.parentElement.children=hijo.parentElement.children.filter(c=>c!==hijo);
            hijo.parentElement=this;this.children.push(hijo);
        }
    }
    replaceChildren() { for(const hijo of this.children)hijo.parentElement=null; this.children = []; if (this.tag === 'select') this._value = undefined; }
    setAttribute(k, v) { this.attributes[k] = v; }
    focus() { this.focused = true; }
    requestSubmit() { return this.onsubmit({preventDefault() {}, target:this}); }
    reset() { for (const c of this.campos || []) c.value = ''; }
}
const pausa = () => new Promise(setImmediate);
const diferida = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a;reject=b;}); return {promise,resolve,reject}; };
const textos = el => [el.textContent, ...el.children.map(textos)].join(' ');
const servicio = (id, reservable = true) => ({id_servicio:id, servicio:'Servicio ' + id, precio:20000, monto_abono:5000, duracion_min:60, categoria:'Belleza', descripcion:'Descripción real', reservable});
function iniciar(config = {}) {
    const elementos = {};
    for (const match of html.matchAll(/<(\w+)[^>]*\bid="([^"]+)"/g)) elementos['#' + match[2]] = new Elemento(match[1]);
    for (const el of ['servicio','profesional','hora']) elementos['#' + el].tag = 'select';
    const nombre = new Elemento('input'), correo = new Elemento('input'), telefono = new Elemento('input');
    for (const [clave,campo] of Object.entries({nombre,correo,telefono})) { campo.name = clave; elementos['#formReserva input[name="' + clave + '"]'] = campo; }
    elementos['#formReserva'].campos = [nombre,correo,telefono,elementos['#fecha'],elementos['#servicio'],elementos['#profesional'],elementos['#hora']];
    const filtroNombre = new Elemento('input'), comuna = new Elemento('input'); filtroNombre.name = 'nombre'; comuna.name = 'comuna';
    const categoria = elementos['#categoriaBusqueda'];
    categoria.name = 'id_categoria';
    categoria.disabled = true;
    elementos['#buscar'].campos = [filtroNombre,comuna,categoria];
    elementos['#buscar'].elements = {namedItem: clave => elementos['#buscar'].campos.find(c => c.name === clave)};
    const peticiones = []; let reservasCreadas = 0;
    const contexto = vm.createContext({Intl,Date:config.reloj||Date,setTimeout:config.temporizador,URLSearchParams,console,crypto:require("node:crypto"),
        document:{querySelector:s => { assert(elementos[s], 'Selector existente: ' + s); return elementos[s]; }, createElement:tag => new Elemento(tag)},
        FormData:class { constructor(form) { this.form = form; } *[Symbol.iterator]() { for (const c of this.form.campos || []) if (c.name && !c.disabled) yield [c.name,c.value]; } },
        fetch:async (url, opciones) => {
            peticiones.push({url, method:opciones.method, headers:opciones.headers, body:opciones.body ? JSON.parse(opciones.body) : undefined});
            let datos;
            if (url === '/api/categorias') datos = config.categorias ? await config.categorias() : [{id_categoria:4,nombre:'Belleza'}];
            else if (url.startsWith('/api/emprendimientos?')) datos = config.buscar ? await config.buscar(url) : [{id_emprendimiento:1,nombre:'Belleza Camila',comuna:'Santiago'}];
            else if (/^\/api\/emprendimientos\/\d+\/servicios$/.test(url)) datos = typeof config.servicios === 'function'
                ? await config.servicios(url) : config.servicios || [servicio(1,false),servicio(2)];
            else if (url.startsWith('/api/servicios/')) datos = config.profesionales ? await config.profesionales(url) : [{id_trabajadora:3,nombre:'Camila'},{id_trabajadora:8,nombre:'Profesional dos'}];
            else if (url.startsWith('/api/disponibilidad?')) datos = config.disponibilidad ? await config.disponibilidad(url) : [{hora_inicio:'11:00:00'},{hora_inicio:'12:00:00'}];
            else if (url === '/api/reservas/invitada/contexto') datos = {disponible:true};
            else if (url === '/api/reservas/invitada') {
                if(config.respuestaReserva)return await config.respuestaReserva(opciones);
                if (config.reservar) await config.reservar();
                reservasCreadas++; datos = {reserva:{id_reserva:21,estado:'pendiente_abono',token_consulta:'11111111-1111-4111-8111-111111111111'}};
            } else throw Error('Ruta inesperada: ' + url);
            return {ok:true,status:200,text:async () => JSON.stringify(datos)};
        }
    });
    vm.runInContext(script, contexto);
    const p = {configurarIndicaciones:crearVista=>contexto.configurarIndicaciones(crearVista),suscribirMapa:receptor=>contexto.suscribirMapa(receptor),seleccionarMapa:dato=>contexto.seleccionar(dato),actualizar:(posicion, calcular)=>contexto.actualizarCercania(posicion, calcular),elementos,peticiones,nombre,correo,telefono,filtroNombre,comuna,creadas:() => reservasCreadas,
        async seleccionar() { await pausa(); return elementos['#resultados'].children[0].children[2].onclick(); },
        async preparar() {
            await p.seleccionar(); elementos['#profesional'].value = '3'; elementos['#profesional'].onchange();
            elementos['#fecha'].value = '2030-11-04'; elementos['#fecha'].onchange(); await elementos['#disponibilidad'].onclick();
            elementos['#hora'].value = '11:00:00'; elementos['#hora'].onchange();
            nombre.value = ' Clienta prueba '; correo.value = ' prueba@example.com '; nombre.oninput(); correo.oninput();
        }
    };
    return p;
}

test('Quitar un filtro conserva los demás valores de la búsqueda aplicada y devuelve el foco', async () => {
    const p = iniciar();
    await pausa();
    p.filtroNombre.value = 'Camila';
    p.comuna.value = 'Santiago';
    p.elementos['#categoriaBusqueda'].value = '4';
    await p.elementos['#buscar'].requestSubmit();
    const lista = p.elementos['#filtrosAplicados'];
    assert.deepEqual(lista.children.map(li => li.children[0].attributes['aria-label']), [
        'Quitar filtro Nombre: Camila', 'Quitar filtro Comuna: Santiago', 'Quitar filtro Categoría: Belleza'
    ]);
    p.filtroNombre.value = 'Borrador';
    await lista.children[1].children[0].onclick();
    assert.equal(p.peticiones.at(-1).url, '/api/emprendimientos?nombre=Camila&comuna=&id_categoria=4');
    assert.equal(p.comuna.focused, true);
    assert.equal(lista.children.length, 2);
    await p.elementos['#limpiarBusqueda'].onclick();
    assert.equal(lista.hidden, true);
});

test('El reintento usa los filtros fallidos y anuncia carga y vacío', async () => {
    const respuesta = diferida();
    let intentos = 0;
    const p = iniciar({buscar:() => {
        intentos++;
        if (intentos === 1) return [];
        if (intentos === 2) throw Error('Error simulado');
        return respuesta.promise;
    }});
    await pausa();
    p.comuna.value = 'Santiago';
    await p.elementos['#buscar'].requestSubmit();
    const boton = p.elementos['#reintentarBusqueda'];
    assert.equal(boton.hidden, false);
    p.comuna.value = 'Borrador';
    const reintento = boton.onclick();
    assert.equal(boton.hidden, true);
    assert.equal(p.elementos['#resultados'].attributes['aria-busy'], 'true');
    assert.equal(p.elementos['#tituloCatalogo'].focused, true);
    assert.match(p.peticiones.at(-1).url, /comuna=Santiago/);
    respuesta.resolve([]);
    await reintento;
    assert.equal(p.elementos['#resultados'].attributes['aria-busy'], 'false');
    assert.match(p.elementos['#estado'].textContent, /No encontramos/);
});

test('Categorías se cargan una vez y se combinan con nombre y comuna', async () => {
    const opciones = diferida();
    const p = iniciar({categorias:() => opciones.promise});
    const selector = p.elementos['#categoriaBusqueda'];
    assert.equal(selector.disabled, true);
    assert.equal(p.peticiones[0].url.includes('id_categoria'), false);
    opciones.resolve([{id_categoria:4,nombre:'Belleza'}]);
    await pausa();
    assert.deepEqual(selector.children.map(o => [o.value,o.textContent]), [['','Todas las categorías'],['4','Belleza']]);
    assert.equal(selector.disabled, false);
    assert.equal(p.peticiones.length, 2);
    selector.value = '4';
    p.filtroNombre.value = 'Camila';
    p.comuna.value = 'Santiago';
    await p.elementos['#buscar'].requestSubmit();
    const parametros = new URLSearchParams(p.peticiones.at(-1).url.split('?')[1]);
    assert.deepEqual(Object.fromEntries(parametros), {nombre:'Camila',comuna:'Santiago',id_categoria:'4'});
    await p.seleccionar();
    assert.equal(p.peticiones.some(r => r.url === '/api/emprendimientos/1/servicios'), true);
    assert.match(textos(p.elementos['#listaServicios']), /Servicio 1[\s\S]*Servicio 2/);
});

test('Fallo de categorías conserva la búsqueda manual y distingue vacío de fallo de búsqueda', async () => {
    let fallar = false;
    const p = iniciar({categorias:async () => {throw Error('Sin categorías');},buscar:async () => {
        if (fallar) throw Error('Error de catálogo');
        return [];
    }});
    await pausa();
    assert.match(p.elementos['#estadoCategorias'].textContent, /no están disponibles/);
    assert.equal(p.elementos['#categoriaBusqueda'].disabled, true);
    assert.match(p.elementos['#estado'].textContent, /No encontramos/);
    p.comuna.value = 'Santiago';
    fallar = true;
    await p.elementos['#buscar'].requestSubmit();
    assert.match(p.peticiones.at(-1).url, /comuna=Santiago/);
    assert.equal(p.elementos['#estado'].dataset.tipo, 'error');
    assert.equal(p.elementos['#estado'].textContent, 'Error de catálogo');
});

test('Ver todos invalida la búsqueda por categoría pendiente y conserva el orden local', async () => {
    const antigua = diferida();
    const nueva = [{id_emprendimiento:1,nombre:'Lejano',latitud:8,longitud:0},{id_emprendimiento:2,nombre:'Cercano',latitud:1,longitud:0}];
    const p = iniciar({buscar:url => url.includes('id_categoria=4') ? antigua.promise : nueva});
    await pausa();
    const mapa = [];
    p.suscribirMapa(datos => mapa.push(Array.from(datos, d => d.id_emprendimiento)));
    p.actualizar({latitud:0,longitud:0}, (a,b,c) => c);
    p.elementos['#ordenCercania'].value = 'cercania';
    p.elementos['#categoriaBusqueda'].value = '4';
    p.filtroNombre.value = 'Otro';
    p.comuna.value = 'Otra';
    const pendiente = p.elementos['#buscar'].requestSubmit();
    await p.elementos['#limpiarBusqueda'].onclick();
    antigua.resolve([{id_emprendimiento:3,nombre:'Antiguo'}]);
    await pendiente;
    assert.equal(p.elementos['#categoriaBusqueda'].value, '');
    assert.equal(p.peticiones.at(-1).url, '/api/emprendimientos?nombre=&comuna=');
    assert.deepEqual(mapa.at(-1), [1,2]);
    assert.deepEqual(p.elementos['#resultados'].children.map(el => el.dataset.idNegocio), ['2','1']);
});

test('Front Office usa mensajes neutrales para todos los servicios no reservables', async () => {
    const p = iniciar({servicios:[servicio(1,false)]}); await p.seleccionar();
    assert.match(textos(p.elementos['#listaServicios']), /Este servicio no está disponible para reservar por el momento/);
    assert.doesNotMatch(textos(p.elementos['#listaServicios']) + p.elementos['#estado'].textContent + p.elementos['#avisoServicio'].textContent, /suscrip|deuda|sin profesionales|no tiene profesionales/i);
    assert.equal(p.elementos['#crearReserva'].disabled,true);
    assert(!p.peticiones.some(r => r.url.startsWith('/api/servicios/')));
});
test('Tarjetas muestran datos reales y distinguen servicios reservables', async () => {
    const p = iniciar(); await p.seleccionar(); const tarjetas = p.elementos['#listaServicios'].children;
    assert.equal(tarjetas[0].children.at(-1).disabled,true); assert.equal(tarjetas[1].children.at(-1).disabled,false);
    for (const texto of ['Servicio 2','Belleza Camila','Santiago','Belleza','Descripción real','60 minutos','20.000','5.000','Disponible para reservar']) assert(textos(tarjetas[1]).includes(texto));
    assert.equal(p.elementos['#servicio'].value,'2'); assert.equal(p.elementos['#servicio'].children[1].disabled,true);
});
test('Catálogo muestra fotografías administradas y alternativa ante ausencia, URL externa o fallo', async () => {
    const url='/media/servicios/11111111-1111-4111-8111-111111111111.webp';
    const p=iniciar({servicios:[{...servicio(1),imagen_url:url},{...servicio(2),imagen_url:null},{...servicio(3),imagen_url:'https://externo.example/foto.png'}]});
    await p.seleccionar();const tarjetas=p.elementos['#listaServicios'].children;
    const foto=tarjetas[0].children.find(n=>n.className==='servicio-fotografia');
    assert.equal(foto.children[0].src,url);assert.equal(foto.children[0].alt,'Servicio 1');assert.equal(foto.children[0].loading,'lazy');
    foto.children[0].onerror();assert.equal(foto.children.length,0);assert.match(foto.textContent,/no disponible/);
    for(const t of tarjetas.slice(1))assert.match(textos(t),/Fotografía no disponible/);
});
test('Actualizar servicios renueva foto y precio sin borrar datos de la clienta',async()=>{
    let datos=[servicio(2)];const p=iniciar({servicios:async()=>datos});await p.preparar();
    datos=[{...servicio(2),precio:25000,imagen_url:'/media/servicios/11111111-1111-4111-8111-111111111111.webp'}];
    await p.elementos['#actualizarCatalogoServicios'].onclick();
    assert.equal(p.nombre.value,' Clienta prueba ');assert.equal(p.elementos['#servicio'].value,'2');
    assert.equal(p.elementos['#hora'].value,'');assert.equal(p.elementos['#crearReserva'].disabled,true);
    assert.match(textos(p.elementos['#listaServicios']),/25.000/);
    assert.equal(p.elementos['#listaServicios'].children[0].children.find(n=>n.className==='servicio-fotografia').children[0].tag,'img');
});
test('Actualizar catálogo retira servicios desactivados y conserva hora si nada cambió',async()=>{
    let datos=[servicio(2)];const p=iniciar({servicios:async()=>datos});await p.preparar();
    await p.elementos['#actualizarCatalogoServicios'].onclick();assert.equal(p.elementos['#hora'].value,'11:00:00');
    datos=[];await p.elementos['#actualizarCatalogoServicios'].onclick();assert.equal(p.elementos['#servicio'].value,'');assert.equal(p.elementos['#crearReserva'].disabled,true);
});
test('Profesional y hora requieren selección explícita, sin elegir la primera automáticamente', async () => {
    const p = iniciar(); await p.seleccionar(); assert.equal(p.elementos['#profesional'].value,'');
    assert.equal(p.elementos['#disponibilidad'].disabled,true); assert.match(p.elementos['#seleccionProfesional'].textContent,/Selecciona/);
    p.elementos['#profesional'].value='3'; p.elementos['#profesional'].onchange();
    assert.match(p.elementos['#seleccionProfesional'].textContent,/Camila/); assert.equal(p.elementos['#disponibilidad'].disabled,false);
    p.elementos['#fecha'].value='2030-11-04'; await p.elementos['#disponibilidad'].onclick(); assert.equal(p.elementos['#hora'].value,'');
});
test('Lista vacía de profesionales no inventa una causa interna', async () => {
    const p=iniciar({profesionales:async()=>[]}); await p.seleccionar();
    assert.equal(p.elementos['#avisoServicio'].textContent,'Este servicio no está disponible para reservar por el momento'); assert.equal(p.elementos['#disponibilidad'].disabled,true);
});
test('Ver todos borra ambos filtros', async () => {
    const p=iniciar(); await pausa(); p.filtroNombre.value='Otra'; p.comuna.value='Otra'; p.elementos['#limpiarBusqueda'].onclick(); await pausa();
    assert.equal(p.filtroNombre.value,''); assert.equal(p.comuna.value,''); assert.match(p.peticiones.at(-1).url,/nombre=&comuna=/);
});
test('Disponibilidad exige profesional y fecha y rechaza fechas pasadas', async () => {
    const p=iniciar(); await p.seleccionar(); await p.elementos['#disponibilidad'].onclick();
    p.elementos['#profesional'].value='3'; p.elementos['#profesional'].onchange(); await p.elementos['#disponibilidad'].onclick();
    assert.match(p.elementos['#errorFecha'].textContent,/Selecciona una fecha/);
    p.elementos['#fecha'].value='2000-01-01'; await p.elementos['#disponibilidad'].onclick();
    assert(!p.peticiones.some(r=>r.url.startsWith('/api/disponibilidad')));
});
test('Cambiar fecha o profesional invalida horas y actualiza el resumen', async () => {
    const p=iniciar(); await p.preparar(); assert.equal(p.elementos['#crearReserva'].disabled,false);
    p.elementos['#fecha'].value='2030-11-05'; p.elementos['#fecha'].onchange(); assert.equal(p.elementos['#hora'].value,''); assert.equal(p.elementos['#crearReserva'].disabled,true);
    await p.elementos['#disponibilidad'].onclick(); p.elementos['#hora'].value='11:00:00'; p.elementos['#hora'].onchange();
    p.elementos['#profesional'].value='8'; p.elementos['#profesional'].onchange(); assert.equal(p.elementos['#hora'].value,''); assert.match(textos(p.elementos['#resumen']),/Profesional dos/);
});
test('Respuesta antigua de profesionales no reemplaza la nueva selección', async () => {
    const antigua=diferida(); const p=iniciar({servicios:[servicio(1),servicio(2)],profesionales:async url=>url.includes('/1/')?antigua.promise:[{id_trabajadora:8,nombre:'Actual'}]});
    await pausa(); const pendiente=p.elementos['#resultados'].children[0].children[2].onclick(); await pausa();
    p.elementos['#servicio'].value='2'; await p.elementos['#servicio'].onchange(); antigua.resolve([{id_trabajadora:7,nombre:'Anterior'}]); await pendiente;
    assert.equal(p.elementos['#profesional'].children[1].textContent,'Actual'); assert.equal(p.elementos['#profesional'].value,'');
});
test('Cambiar servicio limpia profesional, hora y resumen anteriores', async () => {
    const p=iniciar({servicios:[servicio(2),servicio(3)]}); await p.preparar(); p.elementos['#servicio'].value='3'; await p.elementos['#servicio'].onchange();
    assert.equal(p.elementos['#profesional'].value,''); assert.equal(p.elementos['#hora'].value,''); assert.equal(p.elementos['#crearReserva'].disabled,true); assert.match(textos(p.elementos['#resumen']),/Servicio 3/);
});
test('Respuesta antigua de disponibilidad no sustituye horas de la fecha actual', async () => {
    const antigua=diferida(); const p=iniciar({disponibilidad:async url=>url.includes('2030-11-04')?antigua.promise:[{hora_inicio:'15:00:00'}]});
    await p.seleccionar(); p.elementos['#profesional'].value='3'; p.elementos['#profesional'].onchange(); p.elementos['#fecha'].value='2030-11-04';
    const pendiente=p.elementos['#disponibilidad'].onclick(); p.elementos['#fecha'].value='2030-11-05'; p.elementos['#fecha'].onchange(); await p.elementos['#disponibilidad'].onclick();
    antigua.resolve([{hora_inicio:'11:00:00'}]); await pendiente;
    assert.equal(p.elementos['#hora'].children[1].value,'15:00:00'); assert.equal(p.elementos['#hora'].children.length,2);
});
test('Errores antiguos de disponibilidad no reemplazan el estado actual', async () => {
    const antigua=diferida(); const p=iniciar({disponibilidad:async url=>url.includes('2030-11-04')?antigua.promise:[]});
    await p.seleccionar(); p.elementos['#profesional'].value='3'; p.elementos['#profesional'].onchange(); p.elementos['#fecha'].value='2030-11-04'; const pendiente=p.elementos['#disponibilidad'].onclick();
    p.elementos['#fecha'].value='2030-11-05'; p.elementos['#fecha'].onchange(); await p.elementos['#disponibilidad'].onclick(); antigua.reject(Error('Error antiguo')); await pendiente;
    assert.match(p.elementos['#estado'].textContent,/No hay horas/); assert.equal(p.elementos['#hora'].attributes['aria-busy'],'false');
});
test('Sin horas se explica cómo continuar y no se inventan opciones', async () => {
    const p=iniciar({disponibilidad:async()=>[]}); await p.preparar(); assert.equal(p.elementos['#hora'].children.length,1); assert.match(p.elementos['#ayudaHora'].textContent,/otra fecha o profesional/);
    await p.elementos['#formReserva'].requestSubmit(); assert.equal(p.creadas(),0);
});
test('Resumen incluye todos los datos y se actualiza al editar correo y hora', async () => {
    const p=iniciar(); await p.preparar(); let texto=textos(p.elementos['#resumen']);
    for(const valor of ['Belleza Camila','Servicio 2','Camila','4 de noviembre de 2030','11:00','Precio total','20.000','Abono requerido','5.000','prueba@example.com']) assert(texto.includes(valor));
    p.correo.value='otro@example.com'; p.correo.oninput(); p.elementos['#hora'].value='12:00:00'; p.elementos['#hora'].onchange(); texto=textos(p.elementos['#resumen']); assert(texto.includes('otro@example.com')); assert(texto.includes('12:00'));
});
test('Validación bloquea nombre vacío, correo inválido y teléfono demasiado largo', async () => {
    const p=iniciar(); await p.preparar();
    for(const [campo,valor,id] of [[p.nombre,'   ','#errorNombre'],[p.correo,'no-es-correo','#errorCorreo'],[p.telefono,'1'.repeat(21),'#errorTelefono']]) {
        const anterior=campo.value; campo.value=valor; campo.oninput(); assert.equal(p.elementos['#crearReserva'].disabled,true); assert(p.elementos[id].textContent);
        await p.elementos['#formReserva'].requestSubmit(); assert.equal(p.creadas(),0); campo.value=anterior; campo.oninput();
    }
    assert.equal(p.elementos['#crearReserva'].disabled,false);
});
test('Datos completos habilitan reserva sin casilla y evitan doble envío', async () => {
    const p=iniciar(); await p.preparar(); assert(!html.includes('confirmarDatos')); assert.equal(p.elementos['#crearReserva'].disabled,false);
    await Promise.all([p.elementos['#formReserva'].requestSubmit(),p.elementos['#formReserva'].requestSubmit()]); assert.equal(p.creadas(),1);
    const envio=p.peticiones.find(r=>r.url==='/api/reservas/invitada'); assert.deepEqual(envio.body,{id_servicio:2,id_trabajadora:3,fecha:'2030-11-04',hora:'11:00',contacto:{nombre:'Clienta prueba',correo:'prueba@example.com',telefono:''}});
    assert.equal(p.elementos['#camposReserva'].disabled,true); assert.equal(p.elementos['#consulta'].hidden,false); assert.match(p.elementos['#consulta'].href,/^\/consulta\/#/); assert.match(p.elementos['#estado'].textContent,/pendiente de abono/); assert.equal(p.elementos['#estado'].dataset.tipo,'exito');
    await p.elementos['#formReserva'].requestSubmit(); assert.equal(p.creadas(),1); assert(!p.peticiones.some(r=>/abonos|suscripcion/.test(r.url)));
});
test('Fallo al reservar conserva intento, bloquea edición y permite verificar', async () => {
    let falla=true; const p=iniciar({reservar:async()=>{if(falla)throw Error('El horario ya no está disponible');}}); await p.preparar(); await p.elementos['#formReserva'].requestSubmit();
    assert.equal(p.creadas(),0); assert.equal(p.elementos['#camposReserva'].disabled,true); assert.equal(p.elementos['#estado'].dataset.tipo,'error'); assert.equal(p.nombre.value,' Clienta prueba ');
    falla=false; await p.elementos['#verificarSolicitud'].onclick(); assert.equal(p.creadas(),1);
});
test('Comenzar otra reserva limpia datos y vuelve a exigir profesional y hora', async () => {
    const p=iniciar(); await p.preparar(); await p.elementos['#formReserva'].requestSubmit(); await p.elementos['#nuevaReserva'].onclick();
    assert.equal(p.elementos['#consulta'].hidden,true); assert.equal(p.nombre.value,''); assert.equal(p.elementos['#profesional'].value,''); assert.equal(p.elementos['#hora'].value,''); assert.equal(p.elementos['#crearReserva'].disabled,true);
});
test('Elegir una tarjeta actualiza el servicio y conserva el foco de teclado', async () => {
    const p=iniciar({servicios:[servicio(2),servicio(3)]}); await p.seleccionar();
    await p.elementos['#listaServicios'].children[1].children.at(-1).onclick();
    assert.equal(p.elementos['#servicio'].value,'3'); assert.equal(p.elementos['#servicio'].focused,true);
    assert.equal(p.elementos['#listaServicios'].children[1].dataset.seleccionado,'true');
});
test('Una búsqueda antigua no reemplaza resultados nuevos ni sus errores', async () => {
    const antigua=diferida(); let veces=0;
    const p=iniciar({buscar:async()=>++veces===1?antigua.promise:[{id_emprendimiento:2,nombre:'Resultado actual'}]});
    await p.elementos['#buscar'].requestSubmit(); antigua.reject(Error('Fallo de búsqueda anterior')); await pausa();
    assert.match(textos(p.elementos['#resultados']),/Resultado actual/); assert.doesNotMatch(p.elementos['#estado'].textContent,/Fallo/);
});
test('Un error actual de profesionales se muestra y bloquea la disponibilidad', async () => {
    const p=iniciar({profesionales:async()=>{throw Error('No se pudieron consultar profesionales');}}); await p.seleccionar();
    assert.equal(p.elementos['#estado'].dataset.tipo,'error'); assert.match(p.elementos['#avisoServicio'].textContent,/No se pudieron consultar/);
    assert.equal(p.elementos['#disponibilidad'].disabled,true); assert.equal(p.elementos['#crearReserva'].disabled,true);
});
test('Identidad visual conserva los archivos oficiales byte por byte', () => {
    const {createHash}=require('node:crypto');
    const originales={
        'banner-meraki.png':'0c7372461c90e55a55c9a3466c1b1efec4fda9f38e435cc2e4b7ac46b159c568',
        'logo-meraki.png':'cd4ffd031131710d20a45ee590d67d25428223a582a7c3e55e807ae2b49b29cd',
        'banner-meraki-nuevo.png':'26bf7e8ecd8790ce0ac47b2d187011ecbe22300ea008134da07f12b3ea373b70',
        'logo-meraki-transparente.png':'bb9e55a3e6eb37013fe497a8975e2f02705c074271f0b5303c1b48b56e7fc99d'
    };
    for(const [archivo,huella] of Object.entries(originales)){
        const bytes=fs.readFileSync(path.join(__dirname,'../../frontend/front-office/assets',archivo));
        assert.equal(createHash('sha256').update(bytes).digest('hex'),huella);
    }
});
test('Banner y logo usan rutas relativas, texto accesible y no duplican las frases visibles', () => {
    assert.match(html,/<img[^>]*src="assets\/logo-meraki-transparente\.png"[^>]*alt="Logo oficial de Meraki"/);
    assert.match(html,/<img[^>]*src="assets\/banner-meraki-nuevo\.png"[^>]*alt="Encuentra el cuidado que buscas, cerca de ti\. Descubre servicios de cuidado personal ofrecidos por emprendedoras"/);
    assert(!html.includes('hero-arte'));
    const visible=html.replace(/<[^>]*>/g,'');
    assert(!visible.includes('Encuentra el cuidado que buscas, cerca de ti'));
    assert(!visible.includes('Descubre servicios de cuidado personal ofrecidos por emprendedoras'));
    assert.match(html,/href="styles\.css\?v=/);
});
test('Navegación y etiquetas de campos conservan destinos y ayudas accesibles', () => {
    const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]));
    for(const match of html.matchAll(/href="#([^"]+)"/g))assert(ids.has(match[1]),match[1]);
    for(const match of html.matchAll(/aria-(?:labelledby|describedby)="([^"]+)"/g))for(const id of match[1].split(' '))assert(ids.has(id),id);
    assert.match(html,/href="\/back-office\/"/);assert(!html.includes('confirmarDatos'));
});
test('La fecha del resumen se presenta en español sin modificar la fecha de la API',async()=>{
    const p=iniciar();await p.preparar();
    assert.match(textos(p.elementos['#resumen']),/lunes, 4 de noviembre de 2030/);
    assert.equal(p.elementos['#fecha'].value,'2030-11-04');
    await p.elementos['#formReserva'].requestSubmit();
    assert.equal(p.peticiones.find(r=>r.url==='/api/reservas/invitada').body.fecha,'2030-11-04');
});
test('Los mensajes de reserva permanecen dentro de la reserva y los de búsqueda en el catálogo',async()=>{
    const p=iniciar();await pausa();assert.equal(p.elementos['#estado'].parentElement,p.elementos['#estadoCatalogo']);
    await p.preparar();assert.equal(p.elementos['#estado'].parentElement,p.elementos['#estadoReserva']);
    await p.elementos['#formReserva'].requestSubmit();assert.equal(p.elementos['#estado'].parentElement,p.elementos['#estadoReserva']);
    assert.match(p.elementos['#estado'].textContent,/pendiente de abono/);
    await p.elementos['#buscar'].requestSubmit();assert.equal(p.elementos['#estado'].parentElement,p.elementos['#estadoCatalogo']);
    assert.doesNotMatch(p.elementos['#estado'].textContent,/pendiente de abono/);
});

test('Al cambiar de negocio, carga y error son visibles y el botón permite reintentar',async()=>{
    const fallo=diferida();
    const a={id_emprendimiento:1,nombre:'Negocio A'}, b={id_emprendimiento:2,nombre:'Negocio B'};
    let intentosB=0;
    const p=iniciar({buscar:()=>[a,b],servicios:url=>url.includes('/2/') && ++intentosB===1
        ? fallo.promise : [servicio(url.includes('/2/')?2:1)]});
    await p.preparar();
    const e=p.elementos, aviso=e['#estado'], catalogo=e['#estadoCatalogo'];
    const boton=e['#resultados'].children[1].children[2];
    assert.equal(boton.tag,'button');
    assert.equal(boton.type,'button');
    boton.focus();
    const carga=boton.onclick();
    assert.equal(aviso.parentElement,catalogo);
    assert.equal(catalogo.hidden,false);
    assert.match(aviso.textContent,/Cargando servicios de Negocio B/);
    assert.equal(e['#reserva'].hidden,true);
    assert.equal(e['#listaServicios'].children.length,0);
    for(const id of ['#servicio','#profesional','#hora','#fecha']) assert.equal(e[id].value,'');
    assert.equal(e['#crearReserva'].disabled,true);
    assert.equal(e['#resultados'].children.length,2);
    fallo.reject(Error('Fallo ficticio'));
    await carga;
    assert.equal(aviso.parentElement,catalogo);
    assert.equal(catalogo.children.filter(n=>n===aviso).length,1);
    assert.equal(aviso.dataset.tipo,'error');
    assert.match(aviso.textContent,/Negocio B.*reintentar/);
    assert.match(html,/<p id="estado" role="status" aria-live="polite" aria-atomic="true">/);
    assert.equal(boton.focused,true);
    await boton.onclick();
    assert.equal(e['#reserva'].hidden,false);
    assert.equal(e['#servicio'].value,'2');
    assert.equal(aviso.parentElement,e['#estadoReserva']);
    assert.equal(catalogo.children.includes(aviso),false);
});

test('A → B → A ignora errores y respuestas de servicios obsoletos',async()=>{
    const primera=diferida(), segunda=diferida(), vigente=diferida();
    const respuestas=[primera,segunda,vigente];
    const a={id_emprendimiento:1,nombre:'Negocio A'}, b={id_emprendimiento:2,nombre:'Negocio B'};
    const p=iniciar({buscar:()=>[a,b],servicios:()=>respuestas.shift().promise});
    await pausa();
    const botones=p.elementos['#resultados'].children.map(t=>t.children[2]);
    const cargas=[botones[0].onclick(),botones[1].onclick(),botones[0].onclick()];
    segunda.reject(Error('Fallo obsoleto de B'));
    await cargas[1];
    assert.match(p.elementos['#estado'].textContent,/Cargando servicios de Negocio A/);
    vigente.resolve([servicio(3)]);
    await cargas[2];
    primera.resolve([servicio(1)]);
    await cargas[0];
    assert.equal(p.elementos['#servicio'].value,'3');
    assert.equal(p.elementos['#tituloReserva'].textContent,'Reserva en Negocio A');
    assert.equal(p.elementos['#estado'].parentElement,p.elementos['#estadoReserva']);
    assert.equal(p.creadas(),0);
});

test('Errores aparecen solo en campos interactuados o al intentar continuar', async () => {
    const p = iniciar(); await p.seleccionar();
    for (const id of ['#errorNombre', '#errorCorreo', '#errorTelefono', '#errorFecha']) assert.equal(p.elementos[id].textContent, '');
    p.nombre.value = 'Clienta'; p.nombre.oninput();
    assert.equal(p.elementos['#errorCorreo'].textContent, '');
    assert.equal(p.elementos['#errorFecha'].textContent, '');
    p.correo.onblur(); assert.match(p.elementos['#errorCorreo'].textContent, /Escribe tu correo/);
    p.correo.value = 'clienta@example.com'; p.correo.oninput(); assert.equal(p.elementos['#errorCorreo'].textContent, '');
    await p.elementos['#formReserva'].requestSubmit(); assert.match(p.elementos['#errorFecha'].textContent, /Selecciona una fecha/);
    assert.equal(p.creadas(), 0);
});


test('Cercanía calcula, ordena con empates estables y conserva ausencias e inválidos', async()=>{
 const {distanciaKm}=await import('../../frontend/front-office/geografia.mjs');
 const datos=[{id_emprendimiento:1,nombre:'Lejos',latitud:'0',longitud:'2'},{id_emprendimiento:2,nombre:'Ausente',latitud:null,longitud:null},{id_emprendimiento:3,nombre:'Cerca A',latitud:0,longitud:1},{id_emprendimiento:4,nombre:'Inválido',latitud:91,longitud:0},{id_emprendimiento:5,nombre:'Cerca B',latitud:0,longitud:1}];
 const p=iniciar({buscar:async()=>datos});await pausa();
 const nombres=()=>p.elementos['#resultados'].children.map(c=>c.children[0].textContent);
 assert.deepEqual(nombres(),datos.map(d=>d.nombre));
 p.actualizar({latitud:0,longitud:0},distanciaKm);
 assert.match(textos(p.elementos['#resultados'].children[0]),/222,4 km/);
 assert.match(textos(p.elementos['#resultados'].children[1]),/Distancia no disponible/);
 p.elementos['#ordenCercania'].value='cercania';p.elementos['#ordenCercania'].onchange();
 assert.deepEqual(nombres(),['Cerca A','Cerca B','Lejos','Ausente','Inválido']);
 p.actualizar({latitud:0,longitud:2},distanciaKm);assert.equal(nombres()[0],'Lejos');
 p.actualizar(null,distanciaKm);assert.deepEqual(nombres(),datos.map(d=>d.nombre));assert.doesNotMatch(textos(p.elementos['#resultados']),/km|Distancia no disponible/);
 assert.equal(p.elementos['#controlCercania'].hidden,true);
});

test('Cercanía conserva filtros, descarta respuestas antiguas y usa ubicación actual',async()=>{
 const {distanciaKm}=await import('../../frontend/front-office/geografia.mjs');const antigua=diferida();let veces=0;
 const p=iniciar({buscar:async()=>++veces===1?antigua.promise:[{id_emprendimiento:2,nombre:'Filtrado',latitud:0,longitud:1}]});
 p.filtroNombre.value='Filtrado';p.comuna.value='Santiago';p.actualizar({latitud:0,longitud:0},distanciaKm);
 p.elementos['#ordenCercania'].value='cercania';await p.elementos['#buscar'].requestSubmit();
 assert.match(p.peticiones.at(-1).url,/nombre=Filtrado&comuna=Santiago/);
 p.actualizar({latitud:0,longitud:1},distanciaKm);
 antigua.resolve([{id_emprendimiento:9,nombre:'Antiguo',latitud:0,longitud:5}]);await pausa();
 assert.match(textos(p.elementos['#resultados']),/Filtrado/);assert.doesNotMatch(textos(p.elementos['#resultados']),/Antiguo/);
 assert.match(textos(p.elementos['#resultados']),/menos de 0,1 km/);
 p.actualizar(null,distanciaKm);assert.doesNotMatch(textos(p.elementos['#resultados']),/km/);
 assert(p.peticiones.every(r=>r.method==='GET'&&!r.url.includes('latitud')&&!r.url.includes('longitud')));
});

test('Reordenar catálogo no cambia servicio, profesional, horas ni reserva preparada',async()=>{
 const {distanciaKm}=await import('../../frontend/front-office/geografia.mjs');const p=iniciar();await p.preparar();
 const antes=['#servicio','#profesional','#fecha','#hora'].map(id=>p.elementos[id].value);
 p.actualizar({latitud:0,longitud:0},distanciaKm);p.elementos['#ordenCercania'].value='cercania';p.elementos['#ordenCercania'].onchange();p.actualizar(null,distanciaKm);
 assert.deepEqual(['#servicio','#profesional','#fecha','#hora'].map(id=>p.elementos[id].value),antes);assert.equal(p.elementos['#crearReserva'].disabled,false);assert.equal(p.creadas(),0);
});

test('Una API tardía tras retirar ubicación no restaura distancias ni envía coordenadas',async()=>{
 const {distanciaKm}=await import('../../frontend/front-office/geografia.mjs');const respuesta=diferida();
 const p=iniciar({buscar:async()=>respuesta.promise});p.actualizar({latitud:0,longitud:0},distanciaKm);p.actualizar(null,distanciaKm);
 respuesta.resolve([{id_emprendimiento:1,nombre:'Resultado tardío',latitud:0,longitud:1}]);await pausa();
 assert.match(textos(p.elementos['#resultados']),/Resultado tardío/);assert.doesNotMatch(textos(p.elementos['#resultados']),/km|Distancia no disponible/);
 assert.equal(p.elementos['#ordenCercania'].value,'original');
 assert(p.peticiones.every(r=>r.method==='GET'&&!r.body&&!/[?&](latitud|longitud|latitude|longitude)=/.test(r.url)));
});


test('Proveedor del mapa recibe filtros recientes y su selección conserva flujo sin reservas',async()=>{
 const antigua=diferida();let veces=0;const actual={id_emprendimiento:1,nombre:'Demo filtrada',latitud:0,longitud:0};
 const p=iniciar({buscar:async()=>++veces===1?antigua.promise:[actual]});const recibidos=[];
 p.suscribirMapa(datos=>recibidos.push(datos));p.filtroNombre.value='Demo';p.comuna.value='Santiago';await p.elementos['#buscar'].requestSubmit();
 antigua.resolve([{id_emprendimiento:9,nombre:'Viejo'}]);await pausa();assert.equal(recibidos.at(-1)[0].nombre,'Demo filtrada');
 await p.seleccionarMapa(recibidos.at(-1)[0]);assert.equal(p.elementos['#reserva'].hidden,false);assert.equal(p.creadas(),0);
 assert.match(p.peticiones.find(r=>r.url.includes('nombre=Demo')).url,/comuna=Santiago/);assert(p.peticiones.every(r=>r.method==='GET'));
});


test('Indicaciones conserva catálogo y reserva aunque coordenadas de API no estén confirmadas',async()=>{
 const {crearVistaIndicaciones}=await import('../../frontend/front-office/mapa-datos.mjs');
 const p=iniciar({buscar:async()=>[{id_emprendimiento:1,nombre:'Demo',comuna:'Santiago',latitud:0,longitud:0,ubicacion_confirmada:true}]});await p.preparar();
 const doc={createElement:tag=>new Elemento(tag)};
 p.configurarIndicaciones(negocio=>crearVistaIndicaciones(doc,negocio));
 assert.match(textos(p.elementos['#resultados']),/Coordenadas disponibles en el mapa\./);
 assert(!p.elementos['#resultados'].children[0].children.some(n=>n.tag==='a'));
 assert.equal(p.elementos['#crearReserva'].disabled,false);assert.equal(p.creadas(),0);
 assert(p.peticiones.every(r=>r.method==='GET'));
});

const respuestaInvitada=(status=201,body={reserva:{id_reserva:21,estado:'pendiente_abono',token_consulta:'11111111-1111-4111-8111-111111111111'}})=>({ok:status>=200&&status<300,status,headers:{get:()=>null},text:async()=>JSON.stringify(body)});
for(const caso of ['antes de crear','después de crear'])test('Respuesta perdida '+caso+' verifica exactamente la misma operación',async()=>{
 let llamadas=0;const p=iniciar({respuestaReserva:async()=>{if(++llamadas===1)throw Error('Respuesta perdida simulada');return respuestaInvitada(caso==='antes de crear'?201:200);}});await p.preparar();
 await p.elementos['#formReserva'].requestSubmit();assert.equal(p.elementos['#reserva'].dataset.intento,'resultado_incierto');assert.equal(p.elementos['#camposReserva'].disabled,true);
 const antes=p.peticiones.length;await p.elementos['#formReserva'].requestSubmit();assert.equal(p.peticiones.length,antes);
 p.nombre.value='No debe enviarse';p.elementos['#hora'].value='12:00:00';
 await p.elementos['#verificarSolicitud'].onclick();const posts=p.peticiones.filter(x=>x.url==='/api/reservas/invitada');
 assert.deepEqual(posts[0].body,posts[1].body);assert.equal(posts[0].headers['Idempotency-Key'],posts[1].headers['Idempotency-Key']);
 assert.equal(p.peticiones.filter(x=>x.url.endsWith('/contexto')).length,1);assert.equal(p.elementos['#reserva'].dataset.intento,'reserva_completada');assert.match(p.elementos['#estado'].textContent,/recuperada/);
 assert(!p.peticiones.some(x=>/abonos|suscripcion|notificaciones/.test(x.url)));
});
for(const [status,codigo,esperado]of [[409,'HORARIO_NO_DISPONIBLE','rechazo_definitivo'],[409,'CLAVE_CONTENIDO_DISTINTO','resultado_incierto'],[409,'INTENTO_EN_REVISION','resultado_incierto'],[410,'INTENTO_VENCIDO','intento_vencido'],[401,'CONTEXTO_NO_DISPONIBLE','intento_vencido'],[429,'LIMITE_INTENTOS','resultado_incierto'],[503,'NO_DISPONIBLE','resultado_incierto']])test('Reserva distingue HTTP '+status+' '+codigo,async()=>{
 const p=iniciar({respuestaReserva:async()=>respuestaInvitada(status,{codigo,mensaje:'Error simulado'})});await p.preparar();await p.elementos['#formReserva'].requestSubmit();assert.equal(p.elementos['#reserva'].dataset.intento,esperado);
 assert.equal(p.elementos['#camposReserva'].disabled,esperado!=='rechazo_definitivo');
 if(esperado==='intento_vencido'){const n=p.peticiones.length;await p.elementos['#verificarSolicitud'].onclick();await p.elementos['#nuevaReserva'].onclick();assert.equal(p.peticiones.length,n);assert.match(p.elementos['#mensajeRecuperacion'].textContent,/podría existir/);}
});
for(const respuesta of [()=>({ok:true,status:201,text:async()=>'<html>'}),()=>respuestaInvitada(201,{}),()=>respuestaInvitada(200,{reserva:{id_reserva:21}})])test('Respuesta inválida o incompleta conserva incertidumbre',async()=>{
 const p=iniciar({respuestaReserva:async()=>respuesta()});await p.preparar();await p.elementos['#formReserva'].requestSubmit();assert.equal(p.elementos['#reserva'].dataset.intento,'resultado_incierto');assert.equal(p.elementos['#consulta'].hidden,true);
});
test('Durante incertidumbre no cambia negocio, filtros, servicio ni consulta disponibilidad',async()=>{
 const p=iniciar({respuestaReserva:async()=>{throw Error('Desconexión')}});await p.preparar();await p.elementos['#formReserva'].requestSubmit();const n=p.peticiones.length;
 await p.elementos['#buscar'].requestSubmit();await p.elementos['#limpiarBusqueda'].onclick();await p.seleccionarMapa({id_emprendimiento:8,nombre:'Otro'});await p.elementos['#disponibilidad'].onclick();await p.elementos['#nuevaReserva'].onclick();assert.equal(p.peticiones.length,n);assert.equal(p.elementos['#camposReserva'].disabled,true);
});
test('Doble clic de verificación comparte un único envío pendiente',async()=>{
 let n=0;const espera=diferida();const p=iniciar({respuestaReserva:async()=>{if(++n===1)throw Error('Red');return espera.promise;}});await p.preparar();await p.elementos['#formReserva'].requestSubmit();const a=p.elementos['#verificarSolicitud'].onclick();await p.elementos['#verificarSolicitud'].onclick();assert.equal(n,2);espera.resolve(respuestaInvitada(200));await a;assert.equal(p.elementos['#reserva'].dataset.intento,'reserva_completada');
});
test('429 conserva espera Retry-After y no envía antes del plazo',async()=>{
 const p=iniciar({respuestaReserva:async()=>({...respuestaInvitada(429,{codigo:'LIMITE_INTENTOS'}),headers:{get:()=> '30'}})});await p.preparar();await p.elementos['#formReserva'].requestSubmit();const n=p.peticiones.length;await p.elementos['#verificarSolicitud'].onclick();assert.equal(p.peticiones.length,n);assert.equal(p.elementos['#verificarSolicitud'].disabled,true);
});

test('Un aviso temporizado antiguo no modifica un intento posterior',async()=>{
 let ahora=Date.now(),aviso;class Reloj extends Date{static now(){return ahora;}}
 let n=0;const p=iniciar({reloj:Reloj,temporizador:fn=>{aviso=fn;},respuestaReserva:async()=>++n===1?{...respuestaInvitada(429,{codigo:'LIMITE_INTENTOS'}),headers:{get:()=> '1'}}:respuestaInvitada(200)});
 await p.preparar();await p.elementos['#formReserva'].requestSubmit();ahora+=2000;await p.elementos['#verificarSolicitud'].onclick();
 await p.elementos['#nuevaReserva'].onclick();await p.preparar();await p.elementos['#formReserva'].requestSubmit();const texto=p.elementos['#estado'].textContent;aviso();
 assert.equal(p.elementos['#estado'].textContent,texto);assert.equal(p.elementos['#reserva'].dataset.intento,'reserva_completada');assert.equal(p.elementos['#recuperacionReserva'].hidden,true);
});
test('Un rechazo 409 después de una desconexión no descarta el intento incierto',async()=>{
 let n=0;const p=iniciar({respuestaReserva:async()=>{if(++n===1)throw Error('Red');return respuestaInvitada(409,{codigo:'HORARIO_NO_DISPONIBLE'});}});await p.preparar();await p.elementos['#formReserva'].requestSubmit();await p.elementos['#verificarSolicitud'].onclick();assert.equal(p.elementos['#reserva'].dataset.intento,'resultado_incierto');assert.equal(p.elementos['#camposReserva'].disabled,true);
});
test('La recuperación no requiere volver a consultar disponibilidad',async()=>{
 let veces=0;const p=iniciar({respuestaReserva:async()=>{if(++veces===1)throw Error('Red');return respuestaInvitada(200);}});await p.preparar();await p.elementos['#formReserva'].requestSubmit();const n=p.peticiones.filter(x=>x.url.startsWith('/api/disponibilidad')).length;await p.elementos['#verificarSolicitud'].onclick();assert.equal(p.peticiones.filter(x=>x.url.startsWith('/api/disponibilidad')).length,n);
});
