const {test}=require('node:test');const assert=require('node:assert/strict');const {interpretar}=require('../../frontend/back-office/pagos');
const consulta={id_abono:9,id_reserva:20,monto:'5000',estado_local:'pendiente',datos_coinciden:true};
test('Procesamiento y revisión habilitan acciones solo según la capacidad local del servidor',()=>{
    const activo=interpretar({...consulta,estado_proceso_webpay:'en_proceso',puede_recuperar:true});
    assert.equal(activo.puedeRecuperar,false);
    assert.match(activo.titulo,/en proceso/i);
    const incierto={...consulta,estado_proceso_webpay:'incierto',requiere_revision:true};
    assert.equal(interpretar({...incierto,revision_manual:true}).puedeRecuperar,false);
    assert.equal(interpretar({...incierto,puede_reconciliar:true}).puedeRecuperar,true);
});
test('Las fases de creación muestran estado local y no habilitan recuperación',()=>{
    for(const [fase,revision,titulo] of [
        ['creacion_en_curso',false,/Creación en curso/],
        ['creacion_en_curso',true,/requiere revisión/],
        ['resultado_incierto',true,/requiere revisión/],
        ['pendiente_respuesta_pago',false,/Pendiente de respuesta/]
    ]){
        const vista=interpretar({...consulta,fase_webpay:fase,requiere_revision:revision,puede_recuperar:true});
        assert.match(vista.titulo,titulo);
        assert.equal(vista.puedeRecuperar,false);
    }
});
test('Pago iniciado no se presenta como aprobado ni permite recuperación',()=>{const v=interpretar({...consulta,estado_transbank:'INITIALIZED',puede_recuperar:false});assert.equal(v.puedeRecuperar,false);assert.match(v.titulo,/no se ha completado/);assert.match(v.lineas.join(' '),/Reserva 20/);});
test('AUTHORIZED requiere permiso explícito del servidor para recuperar',()=>{assert.equal(interpretar({...consulta,estado_transbank:'AUTHORIZED'}).puedeRecuperar,false);assert.equal(interpretar({...consulta,estado_transbank:'AUTHORIZED',puede_recuperar:true}).puedeRecuperar,true);});
test('Inconsistencia impide recuperación incluso si otro campo la habilita',()=>{const v=interpretar({...consulta,estado_transbank:'AUTHORIZED',datos_coinciden:false,puede_recuperar:true});assert.equal(v.puedeRecuperar,false);assert.match(v.titulo,/no coinciden/);});
test('Pago registrado no invita a repetir recuperación',()=>{const v=interpretar({...consulta,estado_transbank:'AUTHORIZED',estado_local:'aprobado',puede_recuperar:false});assert.equal(v.puedeRecuperar,false);assert.match(v.titulo,/ya está registrado/);});
test('Recuperación completada distingue confirmación de reserva y estado del correo',()=>{const v=interpretar({id_abono:9,id_reserva:20,estado_abono:'aprobado',estado_reserva:'confirmada'});assert.equal(v.puedeRecuperar,false);assert.match(v.titulo,/reserva confirmada/);assert.match(v.lineas.join(' '),/Notificaciones/);});
